"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { signInWithEmailAndPassword } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database } from "@/lib/firebase"
import Link from "next/link"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Verificar si Firebase está inicializado
      if (!auth || !database) {
        // Fallback para autenticación local cuando Firebase no está disponible
        if (email === "admin" && password === "admin") {
          localStorage.setItem("user", JSON.stringify({ email, role: "admin" }))
          router.push("/admin")
        } else {
          setError("Credenciales incorrectas o Firebase no está disponible")
        }
        setIsLoading(false)
        return
      }

      // Autenticación con Firebase
      const userCredential = await signInWithEmailAndPassword(auth, email, password)
      const userId = userCredential.user.uid
      const userRef = ref(database, `users/${userId}`)

      // Obtener información del usuario de la base de datos
      const snapshot = await get(userRef)

      if (snapshot.exists()) {
        const userData = snapshot.val()
        const role = userData.role

        // Guardar información del usuario en localStorage
        localStorage.setItem(
          "user",
          JSON.stringify({
            email: userCredential.user.email,
            uid: userId,
            role: role,
          }),
        )

        // Redireccionar según el rol
        if (role === "admin") {
          router.push("/admin")
        } else if (role === "profesor") {
          router.push("/profesor")
        } else if (role === "estudiante") {
          router.push("/estudiante")
        } else {
          setError("Rol no reconocido. Contacta al administrador.")
        }
      } else {
        // Si el usuario existe en Auth pero no en la base de datos
        setError("No se encontró información del usuario en la base de datos.")
      }
    } catch (err: any) {
      console.error("Error de autenticación:", err)

      // Manejar diferentes tipos de errores
      if (err.code === "auth/user-not-found" || err.code === "auth/wrong-password") {
        setError("Correo o contraseña incorrectos.")
      } else if (err.code === "auth/too-many-requests") {
        setError("Demasiados intentos fallidos. Intente más tarde.")
      } else if (err.code === "auth/invalid-credential") {
        setError("Credenciales inválidas.")
      } else {
        setError("Error al iniciar sesión. Intente nuevamente.")
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
        <h1 className="text-2xl font-bold mb-6 text-center text-blue-700">Iniciar sesión</h1>

        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <input
              type="email"
              placeholder="Correo electrónico"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <div>
            <input
              type="password"
              placeholder="Contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-blue-700 text-white py-3 rounded-lg font-semibold hover:bg-blue-800 disabled:bg-blue-400"
          >
            {isLoading ? "Iniciando sesión..." : "Entrar"}
          </button>
        </form>

        <div className="mt-6 text-center">
          <Link href="/" className="text-blue-600 hover:text-blue-800 text-sm">
            Volver a la página principal
          </Link>
        </div>

        {/* Mensaje para desarrollo */}
        {!auth && (
          <div className="mt-4 p-3 bg-yellow-50 text-yellow-700 text-sm rounded-lg">
            <p>Firebase no está configurado. Puede usar:</p>
            <p>
              <strong>Usuario:</strong> admin
            </p>
            <p>
              <strong>Contraseña:</strong> admin
            </p>
          </div>
        )}
      </div>
    </main>
  )
}
