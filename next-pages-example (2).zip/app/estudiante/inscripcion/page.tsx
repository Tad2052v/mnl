"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, update, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"
import { BookOpen, Users, CheckCircle, AlertCircle } from "lucide-react"

interface Curso {
  id: string
  nombre: string
  descripcion: string
  capacidad: number
  nivel: string
  estudiantesInscritos: number
}

export default function InscripcionCursos() {
  const [cursos, setCursos] = useState<Curso[]>([])
  const [cursosInscritos, setCursosInscritos] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [inscribiendo, setInscribiendo] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [userId, setUserId] = useState("")
  const [userName, setUserName] = useState("")
  const [nivelFiltro, setNivelFiltro] = useState<string>("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserId(userData.uid || "")
          setUserName(userData.email?.split("@")[0] || "Estudiante")

          // Obtener cursos inscritos del usuario
          if (userData.cursos) {
            setCursosInscritos(Array.isArray(userData.cursos) ? userData.cursos : [userData.cursos])
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserId(user.uid)
            setUserName(user.email?.split("@")[0] || "Estudiante")

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            } else {
              // Obtener cursos inscritos del usuario
              if (userData.cursos) {
                setCursosInscritos(Array.isArray(userData.cursos) ? userData.cursos : [userData.cursos])
              }
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos disponibles
  useEffect(() => {
    if (loading || !database) return

    const cursosRef = ref(database, "cursos")
    const unsubscribe = onValue(cursosRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursosData = snapshot.val()
        const cursosArray = Object.entries(cursosData).map(([id, data]: [string, any]) => ({
          id,
          nombre: data.nombre || "Sin nombre",
          descripcion: data.descripcion || "Sin descripción",
          capacidad: data.capacidad || 0,
          nivel: data.nivel || "Sin nivel",
          estudiantesInscritos: data.estudiantesInscritos || 0,
        }))
        setCursos(cursosArray)
      } else {
        setCursos([])
      }
    })

    return () => unsubscribe()
  }, [loading, database])

  // Inscribirse en un curso
  const handleInscripcion = async (cursoId: string) => {
    if (!database || !userId || inscribiendo) return

    setError("")
    setSuccess("")
    setInscribiendo(true)

    try {
      // Verificar si el usuario ya está inscrito
      if (cursosInscritos.includes(cursoId)) {
        throw new Error("Ya estás inscrito en este curso")
      }

      // Verificar si el curso tiene cupo
      const cursoRef = ref(database, `cursos/${cursoId}`)
      const snapshot = await get(cursoRef)

      if (!snapshot.exists()) {
        throw new Error("El curso no existe")
      }

      const cursoData = snapshot.val()
      if (cursoData.estudiantesInscritos >= cursoData.capacidad) {
        throw new Error("El curso está lleno")
      }

      // Actualizar el número de estudiantes inscritos en el curso
      await update(cursoRef, {
        estudiantesInscritos: cursoData.estudiantesInscritos + 1,
      })

      // Actualizar los cursos del usuario
      const userRef = ref(database, `users/${userId}`)
      const userSnapshot = await get(userRef)

      if (userSnapshot.exists()) {
        const userData = userSnapshot.val()
        const cursos = userData.cursos
          ? Array.isArray(userData.cursos)
            ? [...userData.cursos, cursoId]
            : [userData.cursos, cursoId]
          : [cursoId]

        await update(userRef, { cursos })
      } else {
        throw new Error("Usuario no encontrado")
      }

      // Actualizar estado local
      setCursosInscritos([...cursosInscritos, cursoId])
      setSuccess(`Te has inscrito exitosamente en el curso "${cursoData.nombre}"`)
    } catch (error: any) {
      console.error("Error al inscribirse:", error)
      setError(`Error: ${error.message}`)
    } finally {
      setInscribiendo(false)
    }
  }

  // Cancelar inscripción
  const handleCancelarInscripcion = async (cursoId: string) => {
    if (!database || !userId || inscribiendo) return

    setError("")
    setSuccess("")
    setInscribiendo(true)

    try {
      // Verificar si el usuario está inscrito
      if (!cursosInscritos.includes(cursoId)) {
        throw new Error("No estás inscrito en este curso")
      }

      // Actualizar el número de estudiantes inscritos en el curso
      const cursoRef = ref(database, `cursos/${cursoId}`)
      const snapshot = await get(cursoRef)

      if (!snapshot.exists()) {
        throw new Error("El curso no existe")
      }

      const cursoData = snapshot.val()
      await update(cursoRef, {
        estudiantesInscritos: Math.max(0, cursoData.estudiantesInscritos - 1),
      })

      // Actualizar los cursos del usuario
      const userRef = ref(database, `users/${userId}`)
      const userSnapshot = await get(userRef)

      if (userSnapshot.exists()) {
        const userData = userSnapshot.val()
        const cursos = userData.cursos
          ? Array.isArray(userData.cursos)
            ? userData.cursos.filter((id: string) => id !== cursoId)
            : userData.cursos === cursoId
              ? []
              : [userData.cursos]
          : []

        await update(userRef, { cursos })
      } else {
        throw new Error("Usuario no encontrado")
      }

      // Actualizar estado local
      setCursosInscritos(cursosInscritos.filter((id) => id !== cursoId))
      setSuccess(`Has cancelado tu inscripción en el curso "${cursoData.nombre}"`)
    } catch (error: any) {
      console.error("Error al cancelar inscripción:", error)
      setError(`Error: ${error.message}`)
    } finally {
      setInscribiendo(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  // Filtrar cursos por nivel
  const cursosFiltrados = nivelFiltro ? cursos.filter((curso) => curso.nivel === nivelFiltro) : cursos

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Inscripción a Cursos</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <Link href="/estudiante">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver al Portal
            </button>
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        {/* Mensajes de éxito o error */}
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
            <div className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              <p className="text-green-700">{success}</p>
            </div>
          </div>
        )}

        {/* Filtro de nivel */}
        <div className="bg-white p-4 rounded-xl shadow-md mb-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between">
            <h2 className="text-lg font-semibold mb-2 md:mb-0">Filtrar por nivel</h2>
            <div className="flex items-center space-x-2">
              <select
                value={nivelFiltro}
                onChange={(e) => setNivelFiltro(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todos los niveles</option>
                <option value="A1">A1 - Principiante</option>
                <option value="A2">A2 - Elemental</option>
                <option value="B1">B1 - Intermedio</option>
                <option value="B2">B2 - Intermedio alto</option>
                <option value="C1">C1 - Avanzado</option>
                <option value="C2">C2 - Dominio</option>
              </select>
            </div>
          </div>
        </div>

        {/* Lista de cursos */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cursosFiltrados.length > 0 ? (
            cursosFiltrados.map((curso) => {
              const isInscrito = cursosInscritos.includes(curso.id)
              const isFull = curso.estudiantesInscritos >= curso.capacidad

              return (
                <div key={curso.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                  <div className="bg-blue-50 px-6 py-4 border-b border-blue-100">
                    <div className="flex justify-between items-center">
                      <h3 className="text-xl font-semibold text-blue-800">{curso.nombre}</h3>
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                        {curso.nivel}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <p className="text-gray-600 mb-4">{curso.descripcion}</p>

                    <div className="flex items-center mb-4">
                      <Users className="h-5 w-5 text-gray-500 mr-2" />
                      <div className="flex-1">
                        <div className="flex justify-between text-sm text-gray-500 mb-1">
                          <span>Ocupación</span>
                          <span>
                            {curso.estudiantesInscritos}/{curso.capacidad}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full ${
                              isFull ? "bg-red-600" : isInscrito ? "bg-green-600" : "bg-blue-600"
                            }`}
                            style={{
                              width: `${Math.min(100, (curso.estudiantesInscritos / curso.capacidad) * 100)}%`,
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    {isInscrito ? (
                      <button
                        onClick={() => handleCancelarInscripcion(curso.id)}
                        disabled={inscribiendo}
                        className="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 disabled:bg-red-400 flex justify-center items-center"
                      >
                        {inscribiendo ? "Procesando..." : "Cancelar inscripción"}
                      </button>
                    ) : (
                      <button
                        onClick={() => handleInscripcion(curso.id)}
                        disabled={isFull || inscribiendo}
                        className={`w-full py-2 px-4 rounded-lg flex justify-center items-center ${
                          isFull
                            ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                            : "bg-blue-600 text-white hover:bg-blue-700 disabled:bg-blue-400"
                        }`}
                      >
                        {inscribiendo ? "Procesando..." : isFull ? "Curso lleno" : "Inscribirse"}
                      </button>
                    )}
                  </div>
                </div>
              )
            })
          ) : (
            <div className="col-span-full bg-white p-8 rounded-xl shadow-md text-center">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">
                {nivelFiltro ? "No hay cursos disponibles para este nivel." : "No hay cursos disponibles actualmente."}
              </p>
              <p className="mt-2 text-gray-400">Consulta más tarde o contacta con un administrador.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
