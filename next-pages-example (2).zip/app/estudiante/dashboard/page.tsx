"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Tarea {
  id: string
  titulo: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre?: string
}

interface Clase {
  id: string
  nombre: string
  hora: string
  nivel: string
}

export default function EstudianteDashboard() {
  const [tareas, setTareas] = useState<Tarea[]>([])
  const [clases, setClases] = useState<Clase[]>([])
  const [clasesEstudiante, setClasesEstudiante] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")

          // Para demo, asignar todas las clases al estudiante
          const clasesRef = ref(database, "clases")
          const snapshot = await get(clasesRef)
          if (snapshot.exists()) {
            const clasesIds = Object.keys(snapshot.val())
            setClasesEstudiante(clasesIds)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            } else {
              // Obtener las clases asignadas al estudiante
              if (userData.clases) {
                setClasesEstudiante(userData.clases)
              } else {
                // Si no tiene clases asignadas, asignar todas las clases (para demo)
                const clasesRef = ref(database, "clases")
                const snapshot = await get(clasesRef)
                if (snapshot.exists()) {
                  const clasesIds = Object.keys(snapshot.val())
                  setClasesEstudiante(clasesIds)
                }
              }
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos del dashboard
  useEffect(() => {
    if (loading || !database || clasesEstudiante.length === 0) return

    // Cargar tareas asignadas
    const tareasRef = ref(database, "tareas")
    const unsubscribeTareas = onValue(tareasRef, (snapshot) => {
      if (snapshot.exists()) {
        const tareasData = snapshot.val()
        const tareasArray = Object.entries(tareasData)
          .map(([id, data]: [string, any]) => ({
            id,
            titulo: data.titulo || "Sin título",
            fechaEntrega: data.fechaEntrega || "Sin fecha",
            claseAsignada: data.claseAsignada || "",
            claseNombre: data.claseNombre || "",
          }))
          .filter((tarea) => clasesEstudiante.includes(tarea.claseAsignada))
          // Ordenar por fecha de entrega (más cercana primero)
          .sort((a, b) => new Date(a.fechaEntrega).getTime() - new Date(b.fechaEntrega).getTime())
          .slice(0, 5) // Mostrar solo las 5 más recientes
        setTareas(tareasArray)
      }
    })

    // Cargar clases asignadas
    const clasesRef = ref(database, "clases")
    const unsubscribeClases = onValue(clasesRef, (snapshot) => {
      if (snapshot.exists()) {
        const clasesData = snapshot.val()
        const clasesArray = Object.entries(clasesData)
          .filter(([id]) => clasesEstudiante.includes(id))
          .map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            hora: data.hora || "Sin hora",
            nivel: data.nivel || "Sin nivel",
          }))
          // Ordenar por hora
          .sort((a, b) => {
            const horaA = a.hora ? a.hora.replace(":", "") : "0000"
            const horaB = b.hora ? b.hora.replace(":", "") : "0000"
            return Number.parseInt(horaA) - Number.parseInt(horaB)
          })
        setClases(clasesArray)
      }
    })

    return () => {
      unsubscribeTareas()
      unsubscribeClases()
    }
  }, [loading, database, clasesEstudiante])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  // Función para formatear la hora en formato 12 horas
  const formatHora = (hora: string) => {
    if (!hora) return "Hora no especificada"

    try {
      const [hours, minutes] = hora.split(":")
      const hoursNum = Number.parseInt(hours)
      const ampm = hoursNum >= 12 ? "PM" : "AM"
      const hours12 = hoursNum % 12 || 12
      return `${hours12}:${minutes} ${ampm}`
    } catch (e) {
      return hora
    }
  }

  // Función para verificar si una tarea está próxima a vencer (menos de 3 días)
  const isTaskDueSoon = (fechaEntrega: string) => {
    const today = new Date()
    const dueDate = new Date(fechaEntrega)
    const diffTime = dueDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays >= 0 && diffDays <= 3
  }

  // Función para verificar si una tarea está vencida
  const isTaskOverdue = (fechaEntrega: string) => {
    const today = new Date()
    const dueDate = new Date(fechaEntrega)
    return dueDate < today
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dashboard Estudiante</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <Link href="/estudiante">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              Portal Principal
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            Cerrar sesión
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-lg font-semibold mb-2 text-blue-700">Clases</h2>
            <div className="text-3xl font-bold">{clases.length}</div>
            <div className="mt-2 text-sm text-gray-500">Clases asignadas</div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-lg font-semibold mb-2 text-green-700">Tareas</h2>
            <div className="text-3xl font-bold">{tareas.length}</div>
            <div className="mt-2 text-sm text-gray-500">Tareas pendientes</div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Próximas Clases</h2>
              <Link href="/estudiante/clases">
                <button className="text-blue-600 text-sm hover:underline">Ver todas</button>
              </Link>
            </div>
            {clases.length > 0 ? (
              <div className="space-y-4">
                {clases.slice(0, 3).map((clase) => (
                  <div key={clase.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <h3 className="font-medium">{clase.nombre}</h3>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                        {clase.nivel}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Hora: {formatHora(clase.hora)}</p>
                    <Link href={`/estudiante/clases/${clase.id}`}>
                      <button className="mt-2 text-blue-600 text-sm hover:underline">Ver detalles</button>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No hay clases programadas</p>
            )}
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Tareas Pendientes</h2>
              <Link href="/estudiante/tareas">
                <button className="text-blue-600 text-sm hover:underline">Ver todas</button>
              </Link>
            </div>
            {tareas.length > 0 ? (
              <div className="space-y-4">
                {tareas.slice(0, 3).map((tarea) => {
                  const isDueSoon = isTaskDueSoon(tarea.fechaEntrega)
                  const isOverdue = isTaskOverdue(tarea.fechaEntrega)

                  return (
                    <div
                      key={tarea.id}
                      className={`border-l-4 rounded-lg p-4 ${
                        isOverdue
                          ? "border-red-500 bg-red-50"
                          : isDueSoon
                            ? "border-yellow-500 bg-yellow-50"
                            : "border-green-500 bg-green-50"
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium">{tarea.titulo}</h3>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            isOverdue
                              ? "bg-red-100 text-red-800"
                              : isDueSoon
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-green-100 text-green-800"
                          }`}
                        >
                          {isOverdue ? "Vencida" : isDueSoon ? "Próxima a vencer" : "En plazo"}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        Fecha de entrega: {new Date(tarea.fechaEntrega).toLocaleDateString()}
                      </p>
                      <p className="text-sm text-gray-600">Clase: {tarea.claseNombre || "Sin especificar"}</p>
                      <Link href={`/estudiante/tareas/${tarea.id}`}>
                        <button className="mt-2 text-blue-600 text-sm hover:underline">Ver detalles</button>
                      </Link>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No hay tareas pendientes</p>
            )}
          </div>
        </div>

        <div className="mt-8 bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold mb-4">Acciones Rápidas</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Link href="/estudiante/clases">
              <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700">
                Ver Clases
              </button>
            </Link>
            <Link href="/estudiante/tareas">
              <button className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700">
                Ver Tareas
              </button>
            </Link>
            <Link href="/estudiante/perfil">
              <button className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700">
                Mi Perfil
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
