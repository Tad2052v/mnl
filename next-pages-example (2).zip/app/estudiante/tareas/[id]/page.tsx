"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ref, get, onValue, update } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Tarea {
  id: string
  titulo: string
  descripcion: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre: string
  entregado: boolean
  entregadoPor?: string[]
}

export default function DetalleTarea() {
  const [tarea, setTarea] = useState<Tarea | null>(null)
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()
  const params = useParams()
  const tareaId = params.id as string

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos de la tarea
  useEffect(() => {
    if (loading || !database || !tareaId) return

    const tareaRef = ref(database, `tareas/${tareaId}`)
    const unsubscribe = onValue(tareaRef, (snapshot) => {
      if (snapshot.exists()) {
        const tareaData = snapshot.val()
        setTarea({
          id: tareaId,
          ...tareaData,
        })
      } else {
        setError("La tarea no existe o ha sido eliminada")
      }
    })

    return () => unsubscribe()
  }, [loading, database, tareaId])

  // Función para marcar una tarea como entregada
  const handleEntregarTarea = async () => {
    if (!database || !userId || !tarea) return

    try {
      const tareaRef = ref(database, `tareas/${tareaId}`)
      const snapshot = await get(tareaRef)

      if (snapshot.exists()) {
        const tareaData = snapshot.val()
        const entregadoPor = tareaData.entregadoPor || []

        // Verificar si el estudiante ya entregó la tarea
        if (!entregadoPor.includes(userId)) {
          entregadoPor.push(userId)

          await update(tareaRef, {
            entregadoPor,
            entregado: true,
          })

          // Actualizar la tarea local
          setTarea({
            ...tarea,
            entregado: true,
            entregadoPor,
          })
        }
      }
    } catch (error) {
      console.error("Error al entregar tarea:", error)
    }
  }

  // Función para verificar si una tarea está próxima a vencer (menos de 3 días)
  const isTaskDueSoon = (fechaEntrega: string) => {
    const today = new Date()
    const dueDate = new Date(fechaEntrega)
    const diffTime = dueDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays >= 0 && diffDays <= 3
  }

  // Función para verificar si una tarea está vencida
  const isTaskOverdue = (fechaEntrega: string) => {
    const today = new Date()
    const dueDate = new Date(fechaEntrega)
    return dueDate < today
  }

  // Función para verificar si el estudiante ya entregó la tarea
  const isTaskSubmitted = (tarea: Tarea) => {
    return tarea.entregadoPor && tarea.entregadoPor.includes(userId)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
          <h1 className="text-2xl font-bold">Detalle de Tarea</h1>
          <Link href="/estudiante/tareas">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver a Tareas
            </button>
          </Link>
        </header>

        <div className="max-w-4xl mx-auto p-6">
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <h2 className="text-2xl font-bold mb-4 text-red-600">Error</h2>
            <p className="text-gray-700 mb-6">{error}</p>
            <Link href="/estudiante/tareas">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                Volver a la lista de tareas
              </button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  if (!tarea) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
          <h1 className="text-2xl font-bold">Detalle de Tarea</h1>
          <Link href="/estudiante/tareas">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver a Tareas
            </button>
          </Link>
        </header>

        <div className="max-w-4xl mx-auto p-6">
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <p className="text-gray-500 text-lg">Cargando información de la tarea...</p>
          </div>
        </div>
      </div>
    )
  }

  const isDueSoon = isTaskDueSoon(tarea.fechaEntrega)
  const isOverdue = isTaskOverdue(tarea.fechaEntrega)
  const isSubmitted = isTaskSubmitted(tarea)

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Detalle de Tarea</h1>
        <Link href="/estudiante/tareas">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver a Tareas
          </button>
        </Link>
      </header>

      <div className="max-w-4xl mx-auto p-6">
        <div
          className={`bg-white p-8 rounded-xl shadow-md border-l-4 ${
            isSubmitted
              ? "border-green-500"
              : isOverdue
                ? "border-red-500"
                : isDueSoon
                  ? "border-yellow-500"
                  : "border-blue-500"
          }`}
        >
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-3xl font-bold">{tarea.titulo}</h2>
            <div
              className={`px-3 py-1 rounded-full text-xs font-medium ${
                isSubmitted
                  ? "bg-green-100 text-green-800"
                  : isOverdue
                    ? "bg-red-100 text-red-800"
                    : isDueSoon
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-blue-100 text-blue-800"
              }`}
            >
              {isSubmitted ? "Entregada" : isOverdue ? "Vencida" : isDueSoon ? "Próxima a vencer" : "En plazo"}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Descripción</h3>
            <p className="text-gray-700 whitespace-pre-line">{tarea.descripcion}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mb-8">
            <div>
              <h3 className="text-lg font-semibold mb-2">Detalles</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="font-medium mr-2">Fecha de entrega:</span>
                  <span>{new Date(tarea.fechaEntrega).toLocaleDateString()}</span>
                </li>
                <li className="flex items-start">
                  <span className="font-medium mr-2">Clase:</span>
                  <span>{tarea.claseNombre || "Sin especificar"}</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-2">Estado</h3>
              <div
                className={`p-4 rounded-lg ${
                  isSubmitted ? "bg-green-50" : isOverdue ? "bg-red-50" : isDueSoon ? "bg-yellow-50" : "bg-blue-50"
                }`}
              >
                {isSubmitted ? (
                  <p className="text-green-700">Has entregado esta tarea. Tu profesor revisará tu entrega pronto.</p>
                ) : isOverdue ? (
                  <p className="text-red-700">
                    Esta tarea ha vencido. Contacta a tu profesor si necesitas una extensión.
                  </p>
                ) : (
                  <p className="text-blue-700">
                    {isDueSoon
                      ? "¡Esta tarea vence pronto! Asegúrate de entregarla a tiempo."
                      : "Tienes tiempo suficiente para completar esta tarea."}
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            {!isSubmitted && !isOverdue && (
              <button
                onClick={handleEntregarTarea}
                className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
              >
                Entregar tarea
              </button>
            )}

            {isSubmitted && <span className="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg">Ya entregada</span>}
          </div>
        </div>
      </div>
    </div>
  )
}
