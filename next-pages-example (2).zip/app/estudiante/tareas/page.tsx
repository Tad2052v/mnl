"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, onValue, update } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Tarea {
  id: string
  titulo: string
  descripcion: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre: string
  entregado: boolean
  entregadoPor?: string[]
}

export default function TareasEstudiante() {
  const [tareas, setTareas] = useState<Tarea[]>([])
  const [clasesEstudiante, setClasesEstudiante] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const [userId, setUserId] = useState("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
          setUserId(userData.uid || "")

          // Para demo, asignar todas las clases al estudiante
          const clasesRef = ref(database, "clases")
          const snapshot = await get(clasesRef)
          if (snapshot.exists()) {
            const clasesIds = Object.keys(snapshot.val())
            setClasesEstudiante(clasesIds)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")
            setUserId(user.uid)

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            } else {
              // Obtener las clases asignadas al estudiante
              if (userData.curso) {
                setClasesEstudiante(Array.isArray(userData.curso) ? userData.curso : [userData.curso])
              } else {
                // Si no tiene clases asignadas, asignar todas las clases (para demo)
                const clasesRef = ref(database, "clases")
                const snapshot = await get(clasesRef)
                if (snapshot.exists()) {
                  const clasesIds = Object.keys(snapshot.val())
                  setClasesEstudiante(clasesIds)
                }
              }
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar tareas asignadas
  useEffect(() => {
    if (clasesEstudiante.length === 0 || !database) return

    const tareasRef = ref(database, "tareas")
    const unsubscribe = onValue(tareasRef, (snapshot) => {
      if (snapshot.exists()) {
        const tareasData = snapshot.val()
        const tareasArray = Object.entries(tareasData)
          .map(([id, data]: [string, any]) => ({
            id,
            ...data,
          }))
          .filter((tarea) => clasesEstudiante.includes(tarea.claseAsignada))
          // Ordenar por fecha de entrega (más cercana primero)
          .sort((a, b) => new Date(a.fechaEntrega).getTime() - new Date(b.fechaEntrega).getTime())

        setTareas(tareasArray)
      } else {
        setTareas([])
      }
    })

    return () => unsubscribe()
  }, [clasesEstudiante, database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  // Función para marcar una tarea como entregada
  const handleEntregarTarea = async (tareaId: string) => {
    if (!database || !userId) return

    try {
      const tareaRef = ref(database, `tareas/${tareaId}`)
      const snapshot = await get(tareaRef)

      if (snapshot.exists()) {
        const tareaData = snapshot.val()
        const entregadoPor = tareaData.entregadoPor || []

        // Verificar si el estudiante ya entregó la tarea
        if (!entregadoPor.includes(userId)) {
          entregadoPor.push(userId)

          await update(tareaRef, {
            entregadoPor,
            entregado: true,
          })

          // Actualizar la lista local
          setTareas(tareas.map((tarea) => (tarea.id === tareaId ? { ...tarea, entregado: true, entregadoPor } : tarea)))
        }
      }
    } catch (error) {
      console.error("Error al entregar tarea:", error)
    }
  }

  // Función para verificar si una tarea está próxima a vencer (menos de 3 días)
  const isTaskDueSoon = (fechaEntrega: string) => {
    const today = new Date()
    const dueDate = new Date(fechaEntrega)
    const diffTime = dueDate.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays >= 0 && diffDays <= 3
  }

  // Función para verificar si una tarea está vencida
  const isTaskOverdue = (fechaEntrega: string) => {
    const today = new Date()
    const dueDate = new Date(fechaEntrega)
    return dueDate < today
  }

  // Función para verificar si el estudiante ya entregó la tarea
  const isTaskSubmitted = (tarea: Tarea) => {
    return tarea.entregadoPor && tarea.entregadoPor.includes(userId)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Mis Tareas</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <Link href="/estudiante">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver al Portal
            </button>
          </Link>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-6">
        <h2 className="text-2xl font-bold mb-6">Tareas Asignadas</h2>

        {tareas.length > 0 ? (
          <div className="space-y-4">
            {tareas.map((tarea) => {
              const isDueSoon = isTaskDueSoon(tarea.fechaEntrega)
              const isOverdue = isTaskOverdue(tarea.fechaEntrega)
              const isSubmitted = isTaskSubmitted(tarea)

              return (
                <div
                  key={tarea.id}
                  className={`bg-white p-6 rounded-xl shadow-md border-l-4 ${
                    isSubmitted
                      ? "border-green-500"
                      : isOverdue
                        ? "border-red-500"
                        : isDueSoon
                          ? "border-yellow-500"
                          : "border-blue-500"
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <h3 className="text-xl font-semibold">{tarea.titulo}</h3>
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        isSubmitted
                          ? "bg-green-100 text-green-800"
                          : isOverdue
                            ? "bg-red-100 text-red-800"
                            : isDueSoon
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-blue-100 text-blue-800"
                      }`}
                    >
                      {isSubmitted ? "Entregada" : isOverdue ? "Vencida" : isDueSoon ? "Próxima a vencer" : "En plazo"}
                    </div>
                  </div>

                  <p className="mt-2 text-gray-600">{tarea.descripcion}</p>

                  <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-500">
                    <div>
                      <span className="font-medium">Fecha de entrega:</span>{" "}
                      {new Date(tarea.fechaEntrega).toLocaleDateString()}
                    </div>
                    <div>
                      <span className="font-medium">Clase:</span> {tarea.claseNombre || "Sin especificar"}
                    </div>
                  </div>

                  <div className="mt-4 flex justify-end">
                    <Link href={`/estudiante/tareas/${tarea.id}`}>
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700 mr-2">
                        Ver detalles
                      </button>
                    </Link>

                    {!isSubmitted && !isOverdue && (
                      <button
                        onClick={() => handleEntregarTarea(tarea.id)}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-green-700"
                      >
                        Entregar tarea
                      </button>
                    )}

                    {isSubmitted && (
                      <span className="bg-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm">Ya entregada</span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        ) : (
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <p className="text-gray-500 text-lg">No tienes tareas asignadas actualmente.</p>
            <p className="mt-2 text-gray-400">Las tareas asignadas aparecerán aquí.</p>
          </div>
        )}
      </div>
    </div>
  )
}
