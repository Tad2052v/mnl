"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, onValue, get } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Clase {
  id: string
  nombre: string
  descripcion: string
  hora: string
  linkReunion: string
  nivel: string
}

export default function ClasesEstudiante() {
  const [clases, setClases] = useState<Clase[]>([])
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar clases disponibles
  useEffect(() => {
    if (!database) return

    const clasesRef = ref(database, "clases")
    const unsubscribe = onValue(clasesRef, (snapshot) => {
      if (snapshot.exists()) {
        const clasesData = snapshot.val()
        const clasesArray = Object.entries(clasesData).map(([id, data]: [string, any]) => ({
          id,
          ...data,
        }))
        // Ordenar por hora
        clasesArray.sort((a, b) => {
          const horaA = a.hora ? a.hora.replace(":", "") : "0000"
          const horaB = b.hora ? b.hora.replace(":", "") : "0000"
          return Number.parseInt(horaA) - Number.parseInt(horaB)
        })
        setClases(clasesArray)
      } else {
        setClases([])
      }
    })

    return () => unsubscribe()
  }, [database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  // Función para formatear la hora en formato 12 horas
  const formatHora = (hora: string) => {
    if (!hora) return "Hora no especificada"

    try {
      const [hours, minutes] = hora.split(":")
      const hoursNum = Number.parseInt(hours)
      const ampm = hoursNum >= 12 ? "PM" : "AM"
      const hours12 = hoursNum % 12 || 12
      return `${hours12}:${minutes} ${ampm}`
    } catch (e) {
      return hora
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Mis Clases</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <Link href="/estudiante">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver al Portal
            </button>
          </Link>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-6">
        <h2 className="text-2xl font-bold mb-6">Clases Disponibles</h2>

        {clases.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {clases.map((clase) => (
              <div key={clase.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="bg-blue-50 px-6 py-4 border-b border-blue-100">
                  <div className="flex justify-between items-center">
                    <h3 className="text-xl font-semibold text-blue-800">{clase.nombre}</h3>
                    <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                      {clase.nivel || "Nivel no especificado"}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-4">{clase.descripcion}</p>
                  <div className="flex flex-col space-y-3">
                    <div className="flex items-center text-sm">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 text-gray-500 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                      <span>{formatHora(clase.hora)}</span>
                    </div>
                    <a
                      href={clase.linkReunion}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-blue-600 text-white text-center py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 mr-2"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                        />
                      </svg>
                      Unirse a la clase
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <p className="text-gray-500 text-lg">No hay clases disponibles actualmente.</p>
            <p className="mt-2 text-gray-400">Las clases programadas aparecerán aquí.</p>
          </div>
        )}
      </div>
    </div>
  )
}
