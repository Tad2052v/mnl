"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { onAuthStateChanged } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database } from "@/lib/firebase"

export default function EstudiantePanel() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")

  useEffect(() => {
    // Verificar autenticación y rol
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const snapshot = await get(ref(database, `users/${user.uid}`))
            const role = snapshot.val()?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")

            if (role !== "estudiante") {
              if (role === "admin") {
                router.push("/admin")
              } else if (role === "profesor") {
                router.push("/profesor")
              } else {
                router.push("/login")
              }
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Portal del Estudiante</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            Cerrar sesión
          </button>
        </div>
      </header>

      <div className="p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Mi Aprendizaje</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <Link href="/estudiante/clases">
              <div className="bg-blue-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-blue-100">
                <h3 className="text-lg font-medium text-blue-700 mb-2">Ver clases asignadas</h3>
                <p className="text-gray-600 text-sm">Accede a tus clases y material de estudio</p>
              </div>
            </Link>

            <Link href="/estudiante/tareas">
              <div className="bg-green-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-green-100">
                <h3 className="text-lg font-medium text-green-700 mb-2">Ver tareas pendientes</h3>
                <p className="text-gray-600 text-sm">Revisa y entrega tus tareas asignadas</p>
              </div>
            </Link>

            <Link href="/estudiante/alertas">
              <div className="bg-purple-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-purple-100">
                <h3 className="text-lg font-medium text-purple-700 mb-2">Ver alertas y anuncios</h3>
                <p className="text-gray-600 text-sm">Mantente al día con los anuncios importantes</p>
              </div>
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Próximas Clases</h2>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 italic">No hay clases programadas para hoy.</p>
              <button className="mt-4 text-blue-600 hover:text-blue-800">Ver calendario completo</button>
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-4">Tareas Pendientes</h2>
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
              <p className="text-gray-500 italic">No hay tareas pendientes por entregar.</p>
              <button className="mt-4 text-blue-600 hover:text-blue-800">Ver todas las tareas</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
