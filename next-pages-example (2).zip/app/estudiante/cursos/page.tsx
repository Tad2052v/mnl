"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Curso {
  id: string
  nombre: string
  descripcion: string
  nivel: string
}

interface Video {
  id: string
  titulo: string
  descripcion: string
  cursoAsignado: string
  videoUrl: string
}

export default function CursosEstudiante() {
  const [cursos, setCursos] = useState<Curso[]>([])
  const [cursosAsignados, setCursosAsignados] = useState<string[]>([])
  const [videosPorCurso, setVideosPorCurso] = useState<Record<string, Video[]>>({})
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "estudiante") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Estudiante")

          // Para demo, asignar todos los cursos al estudiante
          const cursosRef = ref(database, "cursos")
          const snapshot = await get(cursosRef)
          if (snapshot.exists()) {
            const cursosIds = Object.keys(snapshot.val())
            setCursosAsignados(cursosIds)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Estudiante")

            if (role !== "estudiante") {
              router.push(`/${role || "login"}`)
            } else {
              // Obtener los cursos asignados al estudiante
              if (userData.curso) {
                setCursosAsignados(Array.isArray(userData.curso) ? userData.curso : [userData.curso])
              } else {
                // Si no tiene cursos asignados, asignar todos los cursos (para demo)
                const cursosRef = ref(database, "cursos")
                const snapshot = await get(cursosRef)
                if (snapshot.exists()) {
                  const cursosIds = Object.keys(snapshot.val())
                  setCursosAsignados(cursosIds)
                }
              }
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos
  useEffect(() => {
    if (loading || !database || cursosAsignados.length === 0) return

    const cursosRef = ref(database, "cursos")
    const unsubscribeCursos = onValue(cursosRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursosData = snapshot.val()
        const cursosArray = Object.entries(cursosData)
          .filter(([id]) => cursosAsignados.includes(id))
          .map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            descripcion: data.descripcion || "Sin descripción",
            nivel: data.nivel || "Sin nivel",
          }))
        setCursos(cursosArray)
      } else {
        setCursos([])
      }
    })

    return () => unsubscribeCursos()
  }, [loading, database, cursosAsignados])

  // Cargar videos por curso
  useEffect(() => {
    if (loading || !database || cursosAsignados.length === 0) return

    const videosRef = ref(database, "videos")
    const unsubscribeVideos = onValue(videosRef, (snapshot) => {
      if (snapshot.exists()) {
        const videosData = snapshot.val()
        const videosPorCursoObj: Record<string, Video[]> = {}

        Object.entries(videosData).forEach(([id, data]: [string, any]) => {
          const cursoId = data.cursoAsignado

          if (cursosAsignados.includes(cursoId)) {
            if (!videosPorCursoObj[cursoId]) {
              videosPorCursoObj[cursoId] = []
            }

            videosPorCursoObj[cursoId].push({
              id,
              titulo: data.titulo || "Sin título",
              descripcion: data.descripcion || "",
              cursoAsignado: cursoId,
              videoUrl: data.videoUrl || "",
            })
          }
        })

        setVideosPorCurso(videosPorCursoObj)
      }
    })

    return () => unsubscribeVideos()
  }, [loading, database, cursosAsignados])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Mis Cursos</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <Link href="/estudiante">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver al Portal
            </button>
          </Link>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <h2 className="text-2xl font-bold mb-6">Cursos Disponibles</h2>

        {cursos.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cursos.map((curso) => (
              <div key={curso.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="bg-blue-50 px-6 py-4 border-b border-blue-100">
                  <div className="flex justify-between items-center">
                    <h3 className="text-xl font-semibold text-blue-800">{curso.nombre}</h3>
                    <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                      {curso.nivel}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-600 mb-4">{curso.descripcion}</p>

                  <h4 className="font-medium text-gray-800 mb-2">Videos disponibles</h4>
                  {videosPorCurso[curso.id] && videosPorCurso[curso.id].length > 0 ? (
                    <ul className="space-y-2 mb-4">
                      {videosPorCurso[curso.id].map((video) => (
                        <li key={video.id} className="border border-gray-200 rounded p-2">
                          <Link href={`/estudiante/videos/${video.id}`}>
                            <div className="flex items-center text-blue-600 hover:text-blue-800">
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-5 w-5 mr-2"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
                                />
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                                />
                              </svg>
                              {video.titulo}
                            </div>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-gray-500 text-sm mb-4">No hay videos disponibles para este curso</p>
                  )}

                  <Link href={`/estudiante/cursos/${curso.id}`}>
                    <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors">
                      Ver detalles del curso
                    </button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <p className="text-gray-500 text-lg">No tienes cursos asignados actualmente.</p>
            <p className="mt-2 text-gray-400">Contacta con tu profesor para que te asigne a un curso.</p>
          </div>
        )}
      </div>
    </div>
  )
}
