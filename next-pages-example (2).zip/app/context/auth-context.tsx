"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { onAuthStateChanged, signInWithEmailAndPassword, signOut as firebaseSignOut, type User } from "firebase/auth"
import { auth } from "@/lib/firebase"

interface AuthContextType {
  user: User | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  isFirebaseInitialized: boolean
}

// Valor por defecto para el contexto
const defaultContextValue: AuthContextType = {
  user: null,
  loading: true,
  signIn: async () => {
    throw new Error("AuthContext no inicializado")
  },
  signOut: async () => {
    throw new Error("AuthContext no inicializado")
  },
  isFirebaseInitialized: false,
}

const AuthContext = createContext<AuthContextType>(defaultContextValue)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [isFirebaseInitialized, setIsFirebaseInitialized] = useState(Boolean(auth))

  useEffect(() => {
    // Verificar si Firebase está inicializado
    if (!auth) {
      console.log("Firebase Auth no está disponible")
      setIsFirebaseInitialized(false)
      setLoading(false)
      return
    }

    setIsFirebaseInitialized(true)
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const signIn = async (email: string, password: string) => {
    if (!auth) {
      console.error("Firebase Auth no está inicializado")
      throw new Error("Firebase Auth no está inicializado")
    }
    return await signInWithEmailAndPassword(auth, email, password)
  }

  const signOut = async () => {
    if (!auth) {
      console.error("Firebase Auth no está inicializado")
      localStorage.removeItem("user")
      return
    }
    return await firebaseSignOut(auth)
  }

  const value = {
    user,
    loading,
    signIn,
    signOut,
    isFirebaseInitialized,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  return useContext(AuthContext)
}
