"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, remove } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Tarea {
  id: string
  titulo: string
  descripcion: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre: string
  fechaCreacion: string
}

export default function TareasAdmin() {
  const [tareas, setTareas] = useState<Tarea[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar tareas existentes
  useEffect(() => {
    const fetchTareas = async () => {
      if (!database) return

      try {
        const tareasRef = ref(database, "tareas")
        const snapshot = await get(tareasRef)

        if (snapshot.exists()) {
          const tareasData = snapshot.val()
          const tareasArray = Object.entries(tareasData).map(([id, data]: [string, any]) => ({
            id,
            ...data,
          }))
          setTareas(tareasArray)
        }
      } catch (error) {
        console.error("Error al cargar tareas:", error)
      }
    }

    if (!loading) {
      fetchTareas()
    }
  }, [loading, database])

  // Eliminar tarea
  const handleDelete = async (id: string) => {
    if (!database) return

    if (confirm("¿Estás seguro de que deseas eliminar esta tarea?")) {
      try {
        await remove(ref(database, `tareas/${id}`))
        setTareas(tareas.filter((tarea) => tarea.id !== id))
      } catch (error) {
        console.error("Error al eliminar tarea:", error)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Administración de Tareas</h1>
        <Link href="/admin">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver al Panel
          </button>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Tareas</h2>
          <Link href="/admin/tareas/crear">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Crear Nueva Tarea</button>
          </Link>
        </div>

        {/* Lista de tareas */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {tareas.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Título
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Clase
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Fecha de Entrega
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {tareas.map((tarea) => (
                    <tr key={tarea.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{tarea.titulo}</div>
                        <div className="text-sm text-gray-500 truncate max-w-xs">{tarea.descripcion}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-gray-900">{tarea.claseNombre || "Sin nombre"}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-gray-900">{new Date(tarea.fechaEntrega).toLocaleDateString()}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onClick={() => handleDelete(tarea.id)} className="text-red-600 hover:text-red-900 mr-4">
                          Eliminar
                        </button>
                        <Link href={`/admin/tareas/editar/${tarea.id}`} className="text-blue-600 hover:text-blue-900">
                          Editar
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-500">
              No hay tareas disponibles. Crea una nueva tarea para comenzar.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
