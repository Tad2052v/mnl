"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, update, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Usuario {
  id: string
  email: string
  role: string
  curso?: string
  nombre?: string
}

interface Curso {
  id: string
  nombre: string
  nivel: string
  estudiantes: string[]
  profesores: string[]
}

export default function GestionarUsuarios() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([])
  const [cursos, setCursos] = useState<Record<string, Curso>>({})
  const [selectedUser, setSelectedUser] = useState<Usuario | null>(null)
  const [cursoAsignado, setCursoAsignado] = useState("")
  const [loading, setLoading] = useState(true)
  const [updating, setUpdating] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [filtroRole, setFiltroRole] = useState<string>("")
  const [filtroCurso, setFiltroCurso] = useState<string>("")
  const [busqueda, setBusqueda] = useState<string>("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos
  useEffect(() => {
    if (loading || !database) return

    const cursosRef = ref(database, "cursos")
    const unsubscribeCursos = onValue(cursosRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursosData = snapshot.val()
        const cursosMap: Record<string, Curso> = {}

        Object.entries(cursosData).forEach(([id, data]: [string, any]) => {
          cursosMap[id] = {
            id,
            nombre: data.nombre || "Sin nombre",
            nivel: data.nivel || "Sin nivel",
            estudiantes: data.estudiantes || [],
            profesores: data.profesores || [],
          }
        })

        setCursos(cursosMap)
      }
    })

    return () => unsubscribeCursos()
  }, [loading, database])

  // Cargar usuarios
  useEffect(() => {
    if (loading || !database) return

    const usuariosRef = ref(database, "users")
    const unsubscribeUsuarios = onValue(usuariosRef, (snapshot) => {
      if (snapshot.exists()) {
        const usuariosData = snapshot.val()
        const usuariosArray = Object.entries(usuariosData).map(([id, data]: [string, any]) => ({
          id,
          email: data.email || "Sin correo",
          role: data.role || "estudiante",
          curso: data.curso || "",
          nombre: data.nombre || data.email?.split("@")[0] || "Sin nombre",
        }))
        setUsuarios(usuariosArray)
      } else {
        setUsuarios([])
      }
    })

    return () => unsubscribeUsuarios()
  }, [loading, database])

  const handleSelectUser = (usuario: Usuario) => {
    setSelectedUser(usuario)
    setCursoAsignado(usuario.curso || "")
    setError("")
    setSuccess("")
  }

  const handleActualizarUsuario = async () => {
    if (!selectedUser || !database) return

    setUpdating(true)
    setError("")
    setSuccess("")

    try {
      // Obtener el curso actual del usuario
      const cursoAnterior = selectedUser.curso

      // Actualizar el curso del usuario
      const userRef = ref(database, `users/${selectedUser.id}`)
      await update(userRef, { curso: cursoAsignado || null })

      // Si el usuario tenía un curso asignado anteriormente, eliminarlo de ese curso
      if (cursoAnterior && cursos[cursoAnterior]) {
        const cursoAnteriorRef = ref(database, `cursos/${cursoAnterior}`)
        const cursoAnteriorData = cursos[cursoAnterior]

        if (selectedUser.role === "estudiante" && cursoAnteriorData.estudiantes) {
          const nuevosEstudiantes = cursoAnteriorData.estudiantes.filter((id) => id !== selectedUser.id)
          await update(cursoAnteriorRef, { estudiantes: nuevosEstudiantes })
        } else if (selectedUser.role === "profesor" && cursoAnteriorData.profesores) {
          const nuevosProfesores = cursoAnteriorData.profesores.filter((id) => id !== selectedUser.id)
          await update(cursoAnteriorRef, { profesores: nuevosProfesores })
        }
      }

      // Si se asignó un nuevo curso, añadir el usuario a ese curso
      if (cursoAsignado && cursos[cursoAsignado]) {
        const cursoNuevoRef = ref(database, `cursos/${cursoAsignado}`)
        const cursoNuevoData = cursos[cursoAsignado]

        if (selectedUser.role === "estudiante") {
          const nuevosEstudiantes = cursoNuevoData.estudiantes
            ? [...cursoNuevoData.estudiantes, selectedUser.id]
            : [selectedUser.id]
          await update(cursoNuevoRef, { estudiantes: nuevosEstudiantes })
        } else if (selectedUser.role === "profesor") {
          const nuevosProfesores = cursoNuevoData.profesores
            ? [...cursoNuevoData.profesores, selectedUser.id]
            : [selectedUser.id]
          await update(cursoNuevoRef, { profesores: nuevosProfesores })
        }
      }

      setSuccess("Usuario actualizado exitosamente")

      // Actualizar el usuario seleccionado en la lista local
      setUsuarios(usuarios.map((u) => (u.id === selectedUser.id ? { ...u, curso: cursoAsignado } : u)))
      setSelectedUser({ ...selectedUser, curso: cursoAsignado })
    } catch (error: any) {
      console.error("Error al actualizar usuario:", error)
      setError(`Error al actualizar usuario: ${error.message}`)
    } finally {
      setUpdating(false)
    }
  }

  // Filtrar usuarios
  const usuariosFiltrados = usuarios.filter((usuario) => {
    const matchesRole = filtroRole ? usuario.role === filtroRole : true
    const matchesCurso = filtroCurso ? usuario.curso === filtroCurso : true
    const matchesBusqueda = busqueda
      ? usuario.email.toLowerCase().includes(busqueda.toLowerCase()) ||
        usuario.nombre.toLowerCase().includes(busqueda.toLowerCase())
      : true
    return matchesRole && matchesCurso && matchesBusqueda
  })

  // Obtener el nombre del curso de un usuario
  const getNombreCurso = (cursoId: string | undefined) => {
    if (!cursoId || !cursos[cursoId]) return "Sin curso asignado"
    return `${cursos[cursoId].nombre} - ${cursos[cursoId].nivel}`
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestionar Usuarios</h1>
        <Link href="/admin">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver al Panel
          </button>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        {/* Filtros */}
        <div className="bg-white p-4 rounded-xl shadow-md mb-6">
          <h2 className="text-lg font-semibold mb-4">Filtros</h2>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Buscar</label>
              <input
                type="text"
                placeholder="Buscar por nombre o email"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Filtrar por rol</label>
              <select
                value={filtroRole}
                onChange={(e) => setFiltroRole(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todos los roles</option>
                <option value="estudiante">Estudiantes</option>
                <option value="profesor">Profesores</option>
                <option value="admin">Administradores</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Filtrar por curso</label>
              <select
                value={filtroCurso}
                onChange={(e) => setFiltroCurso(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todos los cursos</option>
                <option value="sin-curso">Sin curso asignado</option>
                {Object.values(cursos).map((curso) => (
                  <option key={curso.id} value={curso.id}>
                    {curso.nombre} - {curso.nivel}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Lista de usuarios */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h2 className="text-xl font-semibold">Usuarios ({usuariosFiltrados.length})</h2>
            </div>
            <div className="overflow-y-auto max-h-[600px]">
              {usuariosFiltrados.length > 0 ? (
                <ul className="divide-y divide-gray-200">
                  {usuariosFiltrados.map((usuario) => (
                    <li
                      key={usuario.id}
                      className={`p-4 hover:bg-gray-50 cursor-pointer ${
                        selectedUser?.id === usuario.id ? "bg-blue-50" : ""
                      }`}
                      onClick={() => handleSelectUser(usuario)}
                    >
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{usuario.email}</p>
                          <p className="text-sm text-gray-500">
                            {usuario.nombre} - Rol: {usuario.role}
                          </p>
                        </div>
                        <span
                          className={`px-2 py-1 text-xs font-medium rounded-full ${
                            usuario.role === "admin"
                              ? "bg-purple-100 text-purple-800"
                              : usuario.role === "profesor"
                                ? "bg-blue-100 text-blue-800"
                                : "bg-green-100 text-green-800"
                          }`}
                        >
                          {usuario.role}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">Curso: {getNombreCurso(usuario.curso)}</p>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="p-4 text-center text-gray-500">No hay usuarios disponibles con los filtros aplicados.</p>
              )}
            </div>
          </div>

          {/* Panel de edición */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h2 className="text-xl font-semibold">Editar Usuario</h2>
            </div>
            {selectedUser ? (
              <div className="p-6">
                <div className="mb-6">
                  <h3 className="text-lg font-medium mb-2">{selectedUser.email}</h3>
                  <p className="text-gray-500">
                    Rol: {selectedUser.role} | ID: {selectedUser.id}
                  </p>
                </div>

                {error && (
                  <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-4">
                    <p className="text-red-700">{error}</p>
                  </div>
                )}

                {success && (
                  <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-4">
                    <p className="text-green-700">{success}</p>
                  </div>
                )}

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Asignar Curso</label>
                    <select
                      value={cursoAsignado}
                      onChange={(e) => setCursoAsignado(e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      disabled={selectedUser.role === "admin"}
                    >
                      <option value="">Sin curso asignado</option>
                      {Object.values(cursos).map((curso) => (
                        <option key={curso.id} value={curso.id}>
                          {curso.nombre} - Nivel {curso.nivel}
                        </option>
                      ))}
                    </select>
                    {selectedUser.role === "admin" && (
                      <p className="text-xs text-gray-500 mt-1">
                        Los administradores no pueden ser asignados a cursos.
                      </p>
                    )}
                  </div>

                  <button
                    onClick={handleActualizarUsuario}
                    disabled={updating || selectedUser.role === "admin" || selectedUser.curso === cursoAsignado}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
                  >
                    {updating ? "Actualizando..." : "Actualizar Usuario"}
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-gray-500">
                <p>Selecciona un usuario para editar</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
