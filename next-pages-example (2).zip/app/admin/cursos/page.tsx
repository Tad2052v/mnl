"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, remove, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Curso {
  id: string
  nombre: string
  descripcion: string
  capacidad: number
  nivel: string
  estudiantes: string[]
  profesores: string[]
  fechaCreacion?: string
}

export default function CursosAdmin() {
  const [cursos, setCursos] = useState<Curso[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos existentes
  useEffect(() => {
    if (loading || !database) return

    const cursosRef = ref(database, "cursos")
    const unsubscribe = onValue(cursosRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursosData = snapshot.val()
        const cursosArray = Object.entries(cursosData).map(([id, data]: [string, any]) => ({
          id,
          nombre: data.nombre || "Sin nombre",
          descripcion: data.descripcion || "Sin descripción",
          capacidad: data.capacidad || 0,
          nivel: data.nivel || "A1",
          estudiantes: data.estudiantes || [],
          profesores: data.profesores || [],
          fechaCreacion: data.fechaCreacion,
        }))
        setCursos(cursosArray)
      } else {
        setCursos([])
      }
    })

    return () => unsubscribe()
  }, [loading, database])

  // Eliminar curso
  const handleDelete = async (id: string) => {
    if (!database) return

    if (confirm("¿Estás seguro de que deseas eliminar este curso?")) {
      try {
        await remove(ref(database, `cursos/${id}`))
        setCursos(cursos.filter((curso) => curso.id !== id))
      } catch (error) {
        console.error("Error al eliminar curso:", error)
      }
    }
  }

  // Contar estudiantes en un curso
  const contarEstudiantes = (estudiantes: string[] | undefined) => {
    if (!estudiantes) return 0
    return Array.isArray(estudiantes) ? estudiantes.length : 0
  }

  // Contar profesores en un curso
  const contarProfesores = (profesores: string[] | undefined) => {
    if (!profesores) return 0
    return Array.isArray(profesores) ? profesores.length : 0
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Administración de Cursos</h1>
        <Link href="/admin">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver al Panel
          </button>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Cursos</h2>
          <Link href="/admin/cursos/crear">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Crear Nuevo Curso</button>
          </Link>
        </div>

        {/* Lista de cursos */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {cursos.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Nombre
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Nivel
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Capacidad
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Estudiantes
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Profesores
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cursos.map((curso) => (
                    <tr key={curso.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{curso.nombre}</div>
                        <div className="text-sm text-gray-500 truncate max-w-xs">{curso.descripcion}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {curso.nivel}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="text-gray-900">{curso.capacidad}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-gray-900">{contarEstudiantes(curso.estudiantes)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-gray-900">{contarProfesores(curso.profesores)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onClick={() => handleDelete(curso.id)} className="text-red-600 hover:text-red-900 mr-4">
                          Eliminar
                        </button>
                        <Link
                          href={`/admin/cursos/editar/${curso.id}`}
                          className="text-blue-600 hover:text-blue-900 mr-4"
                        >
                          Editar
                        </Link>
                        <Link
                          href={`/admin/cursos/gestionar/${curso.id}`}
                          className="text-green-600 hover:text-green-900"
                        >
                          Gestionar
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-500">
              No hay cursos disponibles. Crea un nuevo curso para comenzar.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
