"use client"

import type React from "react"

import { useState, useEffect, useMemo } from "react"
import { useRouter } from "next/navigation"
import { ref, get, remove, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"
import { Search, SortAsc, SortDesc, Edit, Trash2, Users, BookOpen } from "lucide-react"

interface Curso {
  id: string
  nombre: string
  descripcion: string
  capacidad: number
  nivel: string
  fechaCreacion?: string
  estudiantesInscritos: number
}

export default function GestionarCursos() {
  const [cursos, setCursos] = useState<Curso[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState<"nombre" | "nivel" | "capacidad" | "estudiantesInscritos">("nombre")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc")
  const [nivelFiltro, setNivelFiltro] = useState<string>("")
  const [cursoSeleccionado, setCursoSeleccionado] = useState<string>("")
  const [estadisticas, setEstadisticas] = useState({
    totalCursos: 0,
    totalCapacidad: 0,
    totalEstudiantes: 0,
    nivelMasPopular: "",
  })
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin" && userData.role !== "profesor") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin" && role !== "profesor") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos existentes
  useEffect(() => {
    if (loading || !database) return

    const cursosRef = ref(database, "cursos")
    const unsubscribe = onValue(cursosRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursosData = snapshot.val()
        const cursosArray = Object.entries(cursosData).map(([id, data]: [string, any]) => ({
          id,
          nombre: data.nombre || "Sin nombre",
          descripcion: data.descripcion || "Sin descripción",
          capacidad: data.capacidad || 0,
          nivel: data.nivel || "Sin nivel",
          fechaCreacion: data.fechaCreacion,
          estudiantesInscritos: data.estudiantesInscritos || 0,
        }))
        setCursos(cursosArray)

        // Calcular estadísticas
        const totalCursos = cursosArray.length
        const totalCapacidad = cursosArray.reduce((sum, curso) => sum + curso.capacidad, 0)
        const totalEstudiantes = cursosArray.reduce((sum, curso) => sum + curso.estudiantesInscritos, 0)

        // Encontrar el nivel más popular
        const niveles = cursosArray.reduce(
          (acc, curso) => {
            acc[curso.nivel] = (acc[curso.nivel] || 0) + curso.estudiantesInscritos
            return acc
          },
          {} as Record<string, number>,
        )

        let nivelMasPopular = ""
        let maxEstudiantes = 0
        Object.entries(niveles).forEach(([nivel, estudiantes]) => {
          if (estudiantes > maxEstudiantes) {
            maxEstudiantes = estudiantes
            nivelMasPopular = nivel
          }
        })

        setEstadisticas({
          totalCursos,
          totalCapacidad,
          totalEstudiantes,
          nivelMasPopular,
        })
      } else {
        setCursos([])
        setEstadisticas({
          totalCursos: 0,
          totalCapacidad: 0,
          totalEstudiantes: 0,
          nivelMasPopular: "",
        })
      }
    })

    return () => unsubscribe()
  }, [loading, database])

  // Eliminar curso
  const handleDelete = async (id: string) => {
    if (!database) return

    if (confirm("¿Estás seguro de que deseas eliminar este curso?")) {
      try {
        await remove(ref(database, `cursos/${id}`))
        setCursos(cursos.filter((curso) => curso.id !== id))
      } catch (error) {
        console.error("Error al eliminar curso:", error)
      }
    }
  }

  // Cambiar orden
  const toggleSort = (field: "nombre" | "nivel" | "capacidad" | "estudiantesInscritos") => {
    if (sortBy === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortBy(field)
      setSortDirection("asc")
    }
  }

  // Filtrar y ordenar cursos
  const cursosFiltrados = useMemo(() => {
    return cursos
      .filter((curso) => {
        const matchesSearch =
          curso.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
          curso.descripcion.toLowerCase().includes(searchTerm.toLowerCase())
        const matchesNivel = nivelFiltro === "" || curso.nivel === nivelFiltro
        return matchesSearch && matchesNivel
      })
      .sort((a, b) => {
        if (sortBy === "nombre") {
          return sortDirection === "asc" ? a.nombre.localeCompare(b.nombre) : b.nombre.localeCompare(a.nombre)
        } else if (sortBy === "nivel") {
          return sortDirection === "asc" ? a.nivel.localeCompare(b.nivel) : b.nivel.localeCompare(a.nivel)
        } else {
          // Para campos numéricos
          const aValue = a[sortBy]
          const bValue = b[sortBy]
          return sortDirection === "asc" ? aValue - bValue : bValue - aValue
        }
      })
  }, [cursos, searchTerm, nivelFiltro, sortBy, sortDirection])

  // Manejar la selección de curso
  const handleCursoSeleccionado = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCursoSeleccionado(e.target.value)
    if (e.target.value) {
      router.push(`/admin/cursos/editar/${e.target.value}`)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestión de Cursos</h1>
        <div className="flex space-x-2">
          <Link href="/admin/cursos/crear">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Crear Curso
            </button>
          </Link>
          <Link href="/admin">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              Volver al Panel
            </button>
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white p-4 rounded-xl shadow-md flex items-center">
            <div className="bg-blue-100 p-3 rounded-full mr-4">
              <BookOpen className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total de Cursos</p>
              <p className="text-2xl font-bold">{estadisticas.totalCursos}</p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md flex items-center">
            <div className="bg-green-100 p-3 rounded-full mr-4">
              <Users className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Capacidad Total</p>
              <p className="text-2xl font-bold">{estadisticas.totalCapacidad}</p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md flex items-center">
            <div className="bg-purple-100 p-3 rounded-full mr-4">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Estudiantes Inscritos</p>
              <p className="text-2xl font-bold">{estadisticas.totalEstudiantes}</p>
            </div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-md flex items-center">
            <div className="bg-yellow-100 p-3 rounded-full mr-4">
              <BookOpen className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Nivel Más Popular</p>
              <p className="text-2xl font-bold">{estadisticas.nivelMasPopular || "N/A"}</p>
            </div>
          </div>
        </div>

        {/* Filtros y búsqueda */}
        <div className="bg-white p-6 rounded-xl shadow-md mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Buscar cursos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <select
                value={nivelFiltro}
                onChange={(e) => setNivelFiltro(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Todos los niveles</option>
                <option value="A1">A1 - Principiante</option>
                <option value="A2">A2 - Elemental</option>
                <option value="B1">B1 - Intermedio</option>
                <option value="B2">B2 - Intermedio alto</option>
                <option value="C1">C1 - Avanzado</option>
                <option value="C2">C2 - Dominio</option>
              </select>
            </div>

            <div>
              <select
                value={cursoSeleccionado}
                onChange={handleCursoSeleccionado}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Ir a un curso...</option>
                {cursos.map((curso) => (
                  <option key={curso.id} value={curso.id}>
                    {curso.nombre} - {curso.nivel}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Lista de cursos */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {cursosFiltrados.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => toggleSort("nombre")}
                    >
                      <div className="flex items-center">
                        Nombre
                        {sortBy === "nombre" && (
                          <span className="ml-1">
                            {sortDirection === "asc" ? (
                              <SortAsc className="h-4 w-4" />
                            ) : (
                              <SortDesc className="h-4 w-4" />
                            )}
                          </span>
                        )}
                      </div>
                    </th>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => toggleSort("nivel")}
                    >
                      <div className="flex items-center">
                        Nivel
                        {sortBy === "nivel" && (
                          <span className="ml-1">
                            {sortDirection === "asc" ? (
                              <SortAsc className="h-4 w-4" />
                            ) : (
                              <SortDesc className="h-4 w-4" />
                            )}
                          </span>
                        )}
                      </div>
                    </th>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => toggleSort("capacidad")}
                    >
                      <div className="flex items-center">
                        Capacidad
                        {sortBy === "capacidad" && (
                          <span className="ml-1">
                            {sortDirection === "asc" ? (
                              <SortAsc className="h-4 w-4" />
                            ) : (
                              <SortDesc className="h-4 w-4" />
                            )}
                          </span>
                        )}
                      </div>
                    </th>
                    <th
                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                      onClick={() => toggleSort("estudiantesInscritos")}
                    >
                      <div className="flex items-center">
                        Ocupación
                        {sortBy === "estudiantesInscritos" && (
                          <span className="ml-1">
                            {sortDirection === "asc" ? (
                              <SortAsc className="h-4 w-4" />
                            ) : (
                              <SortDesc className="h-4 w-4" />
                            )}
                          </span>
                        )}
                      </div>
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {cursosFiltrados.map((curso) => (
                    <tr key={curso.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{curso.nombre}</div>
                        <div className="text-sm text-gray-500 truncate max-w-xs">{curso.descripcion}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {curso.nivel}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="text-gray-900">{curso.capacidad}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div
                              className={`h-2.5 rounded-full ${
                                (curso.estudiantesInscritos / curso.capacidad) * 100 > 80
                                  ? "bg-red-600"
                                  : (curso.estudiantesInscritos / curso.capacidad) * 100 > 50
                                    ? "bg-yellow-500"
                                    : "bg-green-600"
                              }`}
                              style={{
                                width: `${Math.min(100, (curso.estudiantesInscritos / curso.capacidad) * 100)}%`,
                              }}
                            ></div>
                          </div>
                          <span className="ml-2 text-sm text-gray-600">
                            {curso.estudiantesInscritos}/{curso.capacidad}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex space-x-2">
                          <Link href={`/admin/cursos/editar/${curso.id}`}>
                            <button className="p-1 rounded-full hover:bg-blue-100">
                              <Edit className="h-5 w-5 text-blue-600" />
                            </button>
                          </Link>
                          <button onClick={() => handleDelete(curso.id)} className="p-1 rounded-full hover:bg-red-100">
                            <Trash2 className="h-5 w-5 text-red-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-500">
              {searchTerm || nivelFiltro ? (
                <p>No se encontraron cursos con los filtros aplicados.</p>
              ) : (
                <p>No hay cursos disponibles. Crea un nuevo curso para comenzar.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
