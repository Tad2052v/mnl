"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ref, get, update, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Usuario {
  id: string
  email: string
  role: string
  nombre?: string
}

interface Curso {
  nombre: string
  descripcion: string
  capacidad: number
  nivel: string
  estudiantes: string[]
  profesores: string[]
}

export default function GestionarCurso() {
  const [curso, setCurso] = useState<Curso | null>(null)
  const [estudiantes, setEstudiantes] = useState<Usuario[]>([])
  const [profesores, setProfesores] = useState<Usuario[]>([])
  const [estudiantesDisponibles, setEstudiantesDisponibles] = useState<Usuario[]>([])
  const [profesoresDisponibles, setProfesoresDisponibles] = useState<Usuario[]>([])
  const [estudianteSeleccionado, setEstudianteSeleccionado] = useState("")
  const [profesorSeleccionado, setProfesorSeleccionado] = useState("")
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const router = useRouter()
  const params = useParams()
  const cursoId = params.id as string

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos del curso
  useEffect(() => {
    if (loading || !database || !cursoId) return

    const cursoRef = ref(database, `cursos/${cursoId}`)
    const unsubscribe = onValue(cursoRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursoData = snapshot.val() as Curso
        setCurso(cursoData)
      } else {
        setError("El curso no existe")
      }
    })

    return () => unsubscribe()
  }, [loading, database, cursoId])

  // Cargar usuarios
  useEffect(() => {
    if (loading || !database || !curso) return

    const usuariosRef = ref(database, "users")
    get(usuariosRef)
      .then((snapshot) => {
        if (snapshot.exists()) {
          const usuariosData = snapshot.val()
          const usuariosArray: Usuario[] = []

          Object.entries(usuariosData).forEach(([id, data]: [string, any]) => {
            usuariosArray.push({
              id,
              email: data.email || "Sin correo",
              role: data.role || "estudiante",
              nombre: data.nombre || data.email?.split("@")[0] || "Sin nombre",
            })
          })

          // Filtrar estudiantes y profesores
          const estudiantesArray = usuariosArray.filter((usuario) => usuario.role === "estudiante")
          const profesoresArray = usuariosArray.filter((usuario) => usuario.role === "profesor")

          // Filtrar estudiantes y profesores ya asignados al curso
          const estudiantesAsignados = estudiantesArray.filter(
            (estudiante) => curso.estudiantes && curso.estudiantes.includes(estudiante.id),
          )
          const profesoresAsignados = profesoresArray.filter(
            (profesor) => curso.profesores && curso.profesores.includes(profesor.id),
          )

          // Filtrar estudiantes y profesores disponibles
          const estudiantesDisp = estudiantesArray.filter(
            (estudiante) => !curso.estudiantes || !curso.estudiantes.includes(estudiante.id),
          )
          const profesoresDisp = profesoresArray.filter(
            (profesor) => !curso.profesores || !curso.profesores.includes(profesor.id),
          )

          setEstudiantes(estudiantesAsignados)
          setProfesores(profesoresAsignados)
          setEstudiantesDisponibles(estudiantesDisp)
          setProfesoresDisponibles(profesoresDisp)
        }
      })
      .catch((error) => {
        console.error("Error al cargar usuarios:", error)
      })
  }, [loading, database, curso])

  // Añadir estudiante al curso
  const handleAddEstudiante = async () => {
    if (!database || !curso || !estudianteSeleccionado || submitting) return

    setSubmitting(true)
    setError("")
    setSuccess("")

    try {
      // Verificar si el estudiante ya está asignado
      if (curso.estudiantes && curso.estudiantes.includes(estudianteSeleccionado)) {
        throw new Error("Este estudiante ya está asignado al curso")
      }

      // Verificar si hay capacidad disponible
      if (curso.estudiantes && curso.estudiantes.length >= curso.capacidad) {
        throw new Error("El curso ha alcanzado su capacidad máxima")
      }

      // Añadir estudiante al curso
      const nuevosEstudiantes = curso.estudiantes
        ? [...curso.estudiantes, estudianteSeleccionado]
        : [estudianteSeleccionado]

      await update(ref(database, `cursos/${cursoId}`), {
        estudiantes: nuevosEstudiantes,
      })

      // Actualizar el curso del estudiante
      await update(ref(database, `users/${estudianteSeleccionado}`), {
        curso: cursoId,
      })

      setSuccess("Estudiante añadido al curso exitosamente")
      setEstudianteSeleccionado("")
    } catch (error: any) {
      console.error("Error al añadir estudiante:", error)
      setError(`Error: ${error.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  // Añadir profesor al curso
  const handleAddProfesor = async () => {
    if (!database || !curso || !profesorSeleccionado || submitting) return

    setSubmitting(true)
    setError("")
    setSuccess("")

    try {
      // Verificar si el profesor ya está asignado
      if (curso.profesores && curso.profesores.includes(profesorSeleccionado)) {
        throw new Error("Este profesor ya está asignado al curso")
      }

      // Añadir profesor al curso
      const nuevosProfesores = curso.profesores ? [...curso.profesores, profesorSeleccionado] : [profesorSeleccionado]

      await update(ref(database, `cursos/${cursoId}`), {
        profesores: nuevosProfesores,
      })

      // Actualizar el curso del profesor
      await update(ref(database, `users/${profesorSeleccionado}`), {
        curso: cursoId,
      })

      setSuccess("Profesor añadido al curso exitosamente")
      setProfesorSeleccionado("")
    } catch (error: any) {
      console.error("Error al añadir profesor:", error)
      setError(`Error: ${error.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  // Eliminar estudiante del curso
  const handleRemoveEstudiante = async (estudianteId: string) => {
    if (!database || !curso || submitting) return

    if (confirm("¿Estás seguro de que deseas eliminar este estudiante del curso?")) {
      setSubmitting(true)
      setError("")
      setSuccess("")

      try {
        // Eliminar estudiante del curso
        const nuevosEstudiantes = curso.estudiantes ? curso.estudiantes.filter((id) => id !== estudianteId) : []

        await update(ref(database, `cursos/${cursoId}`), {
          estudiantes: nuevosEstudiantes,
        })

        // Eliminar el curso del estudiante
        await update(ref(database, `users/${estudianteId}`), {
          curso: null,
        })

        setSuccess("Estudiante eliminado del curso exitosamente")
      } catch (error: any) {
        console.error("Error al eliminar estudiante:", error)
        setError(`Error: ${error.message}`)
      } finally {
        setSubmitting(false)
      }
    }
  }

  // Eliminar profesor del curso
  const handleRemoveProfesor = async (profesorId: string) => {
    if (!database || !curso || submitting) return

    if (confirm("¿Estás seguro de que deseas eliminar este profesor del curso?")) {
      setSubmitting(true)
      setError("")
      setSuccess("")

      try {
        // Eliminar profesor del curso
        const nuevosProfesores = curso.profesores ? curso.profesores.filter((id) => id !== profesorId) : []

        await update(ref(database, `cursos/${cursoId}`), {
          profesores: nuevosProfesores,
        })

        // Eliminar el curso del profesor
        await update(ref(database, `users/${profesorId}`), {
          curso: null,
        })

        setSuccess("Profesor eliminado del curso exitosamente")
      } catch (error: any) {
        console.error("Error al eliminar profesor:", error)
        setError(`Error: ${error.message}`)
      } finally {
        setSubmitting(false)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  if (!curso) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
          <h1 className="text-2xl font-bold">Gestionar Curso</h1>
          <Link href="/admin/cursos">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver a Cursos
            </button>
          </Link>
        </header>

        <div className="max-w-4xl mx-auto p-6">
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <h2 className="text-2xl font-bold mb-4 text-red-600">Error</h2>
            <p className="text-gray-700 mb-6">El curso que intentas gestionar no existe o ha sido eliminado.</p>
            <Link href="/admin/cursos">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                Volver a la lista de cursos
              </button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Gestionar Curso: {curso.nombre}</h1>
        <Link href="/admin/cursos">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver a Cursos
          </button>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
            <p className="text-red-700">{error}</p>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
            <p className="text-green-700">{success}</p>
          </div>
        )}

        <div className="bg-white p-6 rounded-xl shadow-md mb-6">
          <h2 className="text-xl font-bold mb-4">Información del Curso</h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <p className="text-gray-600">
                Nombre: <span className="font-semibold text-gray-800">{curso.nombre}</span>
              </p>
              <p className="text-gray-600">
                Nivel: <span className="font-semibold text-gray-800">{curso.nivel}</span>
              </p>
              <p className="text-gray-600">
                Capacidad: <span className="font-semibold text-gray-800">{curso.capacidad}</span>
              </p>
            </div>
            <div>
              <p className="text-gray-600">
                Estudiantes:{" "}
                <span className="font-semibold text-gray-800">
                  {estudiantes.length} / {curso.capacidad}
                </span>
              </p>
              <p className="text-gray-600">
                Profesores: <span className="font-semibold text-gray-800">{profesores.length}</span>
              </p>
              <Link href={`/admin/cursos/editar/${cursoId}`}>
                <button className="mt-2 text-blue-600 hover:text-blue-800">Editar información del curso</button>
              </Link>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Gestión de estudiantes */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold mb-4">Estudiantes</h2>

            {/* Añadir estudiante */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Añadir estudiante</h3>
              <div className="flex space-x-2">
                <select
                  value={estudianteSeleccionado}
                  onChange={(e) => setEstudianteSeleccionado(e.target.value)}
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Seleccionar estudiante</option>
                  {estudiantesDisponibles.map((estudiante) => (
                    <option key={estudiante.id} value={estudiante.id}>
                      {estudiante.email} - {estudiante.nombre}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleAddEstudiante}
                  disabled={!estudianteSeleccionado || submitting}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
                >
                  Añadir
                </button>
              </div>
              {estudiantesDisponibles.length === 0 && (
                <p className="text-sm text-gray-500 mt-2">No hay estudiantes disponibles para añadir.</p>
              )}
            </div>

            {/* Lista de estudiantes */}
            <div>
              <h3 className="text-lg font-semibold mb-2">Estudiantes asignados</h3>
              {estudiantes.length > 0 ? (
                <ul className="divide-y divide-gray-200">
                  {estudiantes.map((estudiante) => (
                    <li key={estudiante.id} className="py-3 flex justify-between items-center">
                      <div>
                        <p className="font-medium">{estudiante.nombre}</p>
                        <p className="text-sm text-gray-500">{estudiante.email}</p>
                      </div>
                      <button
                        onClick={() => handleRemoveEstudiante(estudiante.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Eliminar
                      </button>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500">No hay estudiantes asignados a este curso.</p>
              )}
            </div>
          </div>

          {/* Gestión de profesores */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-bold mb-4">Profesores</h2>

            {/* Añadir profesor */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Añadir profesor</h3>
              <div className="flex space-x-2">
                <select
                  value={profesorSeleccionado}
                  onChange={(e) => setProfesorSeleccionado(e.target.value)}
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Seleccionar profesor</option>
                  {profesoresDisponibles.map((profesor) => (
                    <option key={profesor.id} value={profesor.id}>
                      {profesor.email} - {profesor.nombre}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleAddProfesor}
                  disabled={!profesorSeleccionado || submitting}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
                >
                  Añadir
                </button>
              </div>
              {profesoresDisponibles.length === 0 && (
                <p className="text-sm text-gray-500 mt-2">No hay profesores disponibles para añadir.</p>
              )}
            </div>

            {/* Lista de profesores */}
            <div>
              <h3 className="text-lg font-semibold mb-2">Profesores asignados</h3>
              {profesores.length > 0 ? (
                <ul className="divide-y divide-gray-200">
                  {profesores.map((profesor) => (
                    <li key={profesor.id} className="py-3 flex justify-between items-center">
                      <div>
                        <p className="font-medium">{profesor.nombre}</p>
                        <p className="text-sm text-gray-500">{profesor.email}</p>
                      </div>
                      <button
                        onClick={() => handleRemoveProfesor(profesor.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        Eliminar
                      </button>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500">No hay profesores asignados a este curso.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
