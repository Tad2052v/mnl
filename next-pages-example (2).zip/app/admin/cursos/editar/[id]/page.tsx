"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ref, update, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Curso {
  nombre: string
  descripcion: string
  capacidad: number
  nivel: string
  estudiantes: string[]
  profesores: string[]
}

export default function EditarCurso() {
  const [nombre, setNombre] = useState("")
  const [descripcion, setDescripcion] = useState("")
  const [capacidad, setCapacidad] = useState("")
  const [nivel, setNivel] = useState("A1")
  const [estudiantes, setEstudiantes] = useState<string[]>([])
  const [profesores, setProfesores] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [cursoExiste, setCursoExiste] = useState(false)
  const router = useRouter()
  const params = useParams()
  const cursoId = params.id as string

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos del curso
  useEffect(() => {
    if (loading || !database || !cursoId) return

    const cursoRef = ref(database, `cursos/${cursoId}`)
    const unsubscribe = onValue(cursoRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursoData = snapshot.val() as Curso
        setNombre(cursoData.nombre || "")
        setDescripcion(cursoData.descripcion || "")
        setCapacidad(cursoData.capacidad?.toString() || "")
        setNivel(cursoData.nivel || "A1")
        setEstudiantes(cursoData.estudiantes || [])
        setProfesores(cursoData.profesores || [])
        setCursoExiste(true)
      } else {
        setError("El curso no existe")
        setCursoExiste(false)
      }
    })

    return () => unsubscribe()
  }, [loading, database, cursoId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")
    setSubmitting(true)

    try {
      if (!database) {
        throw new Error("Firebase no está inicializado")
      }

      if (!cursoExiste) {
        throw new Error("El curso no existe")
      }

      // Validar datos
      if (!nombre.trim()) {
        throw new Error("El nombre del curso es obligatorio")
      }

      if (!capacidad || Number.parseInt(capacidad) <= 0) {
        throw new Error("La capacidad debe ser un número mayor que cero")
      }

      // Actualizar el curso en la base de datos
      await update(ref(database, `cursos/${cursoId}`), {
        nombre,
        descripcion,
        capacidad: Number.parseInt(capacidad),
        nivel,
        fechaActualizacion: new Date().toISOString(),
      })

      setSuccess("Curso actualizado exitosamente")
    } catch (error: any) {
      console.error("Error al actualizar curso:", error)
      setError(`Error al actualizar el curso: ${error.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  if (!cursoExiste && !loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
          <h1 className="text-2xl font-bold">Editar Curso</h1>
          <Link href="/admin/cursos">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver a Cursos
            </button>
          </Link>
        </header>

        <div className="max-w-2xl mx-auto p-6">
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <h2 className="text-2xl font-bold mb-4 text-red-600">Error</h2>
            <p className="text-gray-700 mb-6">El curso que intentas editar no existe o ha sido eliminado.</p>
            <Link href="/admin/cursos">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                Volver a la lista de cursos
              </button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Editar Curso</h1>
        <Link href="/admin/cursos">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver a Cursos
          </button>
        </Link>
      </header>

      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold mb-6">Información del Curso</h2>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {success && (
            <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
              <p className="text-green-700">{success}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="nombre" className="block text-sm font-medium text-gray-700 mb-1">
                Nombre del curso
              </label>
              <input
                id="nombre"
                type="text"
                placeholder="Ej: Español Básico A1"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="nivel" className="block text-sm font-medium text-gray-700 mb-1">
                Nivel
              </label>
              <select
                id="nivel"
                value={nivel}
                onChange={(e) => setNivel(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="A1">A1 - Principiante</option>
                <option value="A2">A2 - Elemental</option>
                <option value="B1">B1 - Intermedio</option>
                <option value="B2">B2 - Intermedio alto</option>
                <option value="C1">C1 - Avanzado</option>
                <option value="C2">C2 - Dominio</option>
              </select>
            </div>

            <div>
              <label htmlFor="capacidad" className="block text-sm font-medium text-gray-700 mb-1">
                Capacidad (número de estudiantes)
              </label>
              <input
                id="capacidad"
                type="number"
                placeholder="Ej: 20"
                value={capacidad}
                onChange={(e) => setCapacidad(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                min="1"
                required
              />
              {estudiantes.length > 0 && (
                <p className="text-xs text-gray-500 mt-1">
                  Actualmente hay {estudiantes.length} estudiantes inscritos en este curso.
                </p>
              )}
            </div>

            <div>
              <label htmlFor="descripcion" className="block text-sm font-medium text-gray-700 mb-1">
                Descripción del curso
              </label>
              <textarea
                id="descripcion"
                placeholder="Describe el contenido y objetivos del curso"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              >
                {submitting ? "Actualizando..." : "Actualizar Curso"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
