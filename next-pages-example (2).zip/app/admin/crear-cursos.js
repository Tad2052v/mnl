// pages/admin/crear-curso.jsx
import React, { useState } from "react";
import { ref, push } from "firebase/database";
import { db } from "../../firebaseConfig";
import { useRouter } from "next/router";

export default function CrearCurso() {
  const [nombre, setNombre] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [cantidad, setCantidad] = useState("");
  const router = useRouter();

  const handleCrearCurso = async (e) => {
    e.preventDefault();
    const nuevoCurso = {
      nombre,
      descripcion,
      cantidad: parseInt(cantidad, 10),
    };

    await push(ref(db, "cursos"), nuevoCurso);
    alert("Curso creado exitosamente");
    router.push("/admin"); // Regresa al panel admin
  };

  return (
    <div className="min-h-screen bg-white p-8 text-gray-800">
      <h1 className="text-3xl font-bold mb-6">Crear nuevo curso</h1>
      <form onSubmit={handleCrearCurso} className="space-y-4 max-w-xl">
        <div>
          <label className="block font-semibold">Nombre del curso:</label>
          <input
            type="text"
            className="border p-2 w-full"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block font-semibold">Descripción:</label>
          <textarea
            className="border p-2 w-full"
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block font-semibold">Cantidad de personas:</label>
          <input
            type="number"
            className="border p-2 w-full"
            value={cantidad}
            onChange={(e) => setCantidad(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
        >
          Crear curso
        </button>
      </form>
    </div>
  );
}
