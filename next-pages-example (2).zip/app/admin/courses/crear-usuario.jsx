'use client';
import { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, set } from 'firebase/database';
import { auth, db } from '@/lib/firebase'; // Asegúrate de que esto esté bien configurado

export default function CrearUsuario() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rol, setRol] = useState('estudiante');
  const [mensaje, setMensaje] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Crear usuario en Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const uid = userCredential.user.uid;

      // Asignar rol a ese usuario en Firebase Realtime Database
      await set(ref(db, `users/${uid}`), {
        email,
        rol,
      });

      setMensaje(`✅ Usuario creado como ${rol}`);
      setEmail('');
      setPassword('');
      setRol('estudiante');
    } catch (error) {
      console.error(error);
      setMensaje('❌ Error al crear el usuario');
    }
  };

  return (
    <div className="min-h-screen bg-white px-4 py-10 max-w-md mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center">Crear Nuevo Usuario</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="email"
          placeholder="Correo electrónico"
          className="w-full border p-2 rounded"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Contraseña"
          className="w-full border p-2 rounded"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <select
          value={rol}
          onChange={(e) => setRol(e.target.value)}
          className="w-full border p-2 rounded"
        >
          <option value="estudiante">Estudiante</option>
          <option value="admin">Administrador</option>
        </select>
        <button
          type="submit"
          className="w-full bg-blue-700 text-white py-2 rounded hover:bg-blue-800"
        >
          Crear Usuario
        </button>
      </form>
      {mensaje && <p className="mt-4 text-center text-sm">{mensaje}</p>}
    </div>
  );
}
