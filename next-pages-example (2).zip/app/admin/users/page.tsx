"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createUserWithEmailAndPassword } from "firebase/auth"
import { ref, set, get } from "firebase/database"
import { useRouter } from "next/navigation"
import { auth, database } from "@/lib/firebase"
import Link from "next/link"

interface Curso {
  id: string
  nombre: string
  nivel: string
}

export default function AdminPanel() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("estudiante")
  const [cursoSeleccionado, setCursoSeleccionado] = useState("")
  const [cursos, setCursos] = useState<Curso[]>([])
  const [message, setMessage] = useState("")
  const [messageType, setMessageType] = useState<"success" | "error">("success")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = () => {
      const user = localStorage.getItem("user")
      if (!user) {
        router.push("/login")
      }
    }

    checkAuth()
  }, [router])

  // Cargar cursos disponibles
  useEffect(() => {
    if (!database) return

    const fetchCursos = async () => {
      try {
        const cursosRef = ref(database, "cursos")
        const snapshot = await get(cursosRef)

        if (snapshot.exists()) {
          const cursosData = snapshot.val()
          const cursosArray = Object.entries(cursosData).map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            nivel: data.nivel || "Sin nivel",
          }))
          setCursos(cursosArray)
        }
      } catch (error) {
        console.error("Error al cargar cursos:", error)
      }
    }

    fetchCursos()
  }, [database])

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setMessage("")

    try {
      if (!auth || !database) {
        throw new Error("Firebase no está inicializado correctamente")
      }

      // Crear usuario en Firebase Authentication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const uid = userCredential.user.uid

      // Guardar el rol y curso en la base de datos
      const userData: any = {
        email,
        role,
        createdAt: new Date().toISOString(),
      }

      // Si se seleccionó un curso y el rol es estudiante o profesor, asignar el curso
      if (cursoSeleccionado && (role === "estudiante" || role === "profesor")) {
        userData.curso = cursoSeleccionado

        // Actualizar la lista de estudiantes o profesores en el curso
        const cursoRef = ref(database, `cursos/${cursoSeleccionado}`)
        const cursoSnapshot = await get(cursoRef)

        if (cursoSnapshot.exists()) {
          const cursoData = cursoSnapshot.val()

          if (role === "estudiante") {
            const estudiantes = cursoData.estudiantes || []
            estudiantes.push(uid)
            await set(ref(database, `cursos/${cursoSeleccionado}/estudiantes`), estudiantes)
          } else if (role === "profesor") {
            const profesores = cursoData.profesores || []
            profesores.push(uid)
            await set(ref(database, `cursos/${cursoSeleccionado}/profesores`), profesores)
          }
        }
      }

      await set(ref(database, `users/${uid}`), userData)

      setMessageType("success")
      setMessage(
        `Usuario creado correctamente como ${role}${cursoSeleccionado ? ` y asignado al curso seleccionado` : ""}`,
      )
      setEmail("")
      setPassword("")
      setRole("estudiante")
      setCursoSeleccionado("")
    } catch (error: any) {
      setMessageType("error")

      // Manejar errores específicos
      if (error.code === "auth/email-already-in-use") {
        setMessage("Error: El correo electrónico ya está en uso")
      } else if (error.code === "auth/weak-password") {
        setMessage("Error: La contraseña es demasiado débil")
      } else if (error.code === "auth/invalid-email") {
        setMessage("Error: El formato del correo electrónico no es válido")
      } else {
        setMessage(`Error: ${error.message}`)
      }
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-6 shadow-md">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold">Idioma Sin Límites</h1>
          <div className="flex items-center space-x-4">
            <Link href="/admin">
              <span className="text-white hover:text-blue-100">Dashboard</span>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto py-10 px-6">
        <div className="bg-white rounded-xl shadow-md p-8">
          <h1 className="text-3xl font-bold mb-6 text-blue-700">Panel de Administrador</h1>
          <p className="mb-6 text-gray-600">Crea nuevos usuarios y asígnales roles en el sistema.</p>

          <form onSubmit={handleCreateUser} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email del nuevo usuario</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Contraseña</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                minLength={6}
              />
              <p className="text-xs text-gray-500 mt-1">La contraseña debe tener al menos 6 caracteres</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Rol del usuario</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="estudiante">Estudiante</option>
                <option value="profesor">Profesor</option>
                <option value="admin">Administrador</option>
              </select>
            </div>

            {(role === "estudiante" || role === "profesor") && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Asignar a curso</label>
                <select
                  value={cursoSeleccionado}
                  onChange={(e) => setCursoSeleccionado(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Sin asignar</option>
                  {cursos.map((curso) => (
                    <option key={curso.id} value={curso.id}>
                      {curso.nombre} - Nivel {curso.nivel}
                    </option>
                  ))}
                </select>
                {cursos.length === 0 && (
                  <p className="text-xs text-yellow-600 mt-1">
                    No hay cursos disponibles.{" "}
                    <Link href="/admin/cursos/crear" className="text-blue-600 underline">
                      Crear un curso
                    </Link>
                  </p>
                )}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:bg-blue-400"
            >
              {isLoading ? "Creando usuario..." : "Crear Usuario"}
            </button>

            {message && (
              <div
                className={`p-4 rounded-lg ${
                  messageType === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                }`}
              >
                {message}
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  )
}
