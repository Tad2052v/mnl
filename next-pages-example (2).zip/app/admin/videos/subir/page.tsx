"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { ref as databaseRef, push, get } from "firebase/database"
import { ref as storageRef, uploadBytesResumable, getDownloadURL } from "firebase/storage"
import { database, auth, storage } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Curso {
  id: string
  nombre: string
  nivel: string
}

export default function SubirVideo() {
  const [titulo, setTitulo] = useState("")
  const [descripcion, setDescripcion] = useState("")
  const [cursoAsignado, setCursoAsignado] = useState("")
  const [cursos, setCursos] = useState<Curso[]>([])
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin" && userData.role !== "profesor") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = databaseRef(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin" && role !== "profesor") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos disponibles
  useEffect(() => {
    if (loading || !database) return

    const fetchCursos = async () => {
      try {
        const cursosRef = databaseRef(database, "cursos")
        const snapshot = await get(cursosRef)

        if (snapshot.exists()) {
          const cursosData = snapshot.val()
          const cursosArray = Object.entries(cursosData).map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            nivel: data.nivel || "Sin nivel",
          }))
          setCursos(cursosArray)

          // Seleccionar el primer curso por defecto si hay cursos disponibles
          if (cursosArray.length > 0) {
            setCursoAsignado(cursosArray[0].id)
          }
        }
      } catch (error) {
        console.error("Error al cargar cursos:", error)
      }
    }

    fetchCursos()
  }, [loading, database])

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setVideoFile(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")
    setSubmitting(true)

    try {
      if (!database || !storage) {
        throw new Error("Firebase no está inicializado")
      }

      if (!videoFile) {
        throw new Error("Por favor, selecciona un video para subir")
      }

      if (!titulo.trim()) {
        throw new Error("El título del video es obligatorio")
      }

      if (!cursoAsignado) {
        throw new Error("Por favor, selecciona un curso para asignar el video")
      }

      // Encontrar el curso seleccionado
      const cursoSeleccionado = cursos.find((curso) => curso.id === cursoAsignado)

      // Subir el video a Firebase Storage
      const videoStorageRef = storageRef(storage, `videos/${Date.now()}_${videoFile.name}`)
      const uploadTask = uploadBytesResumable(videoStorageRef, videoFile)

      uploadTask.on(
        "state_changed",
        (snapshot) => {
          // Actualizar el progreso de la subida
          const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100)
          setUploadProgress(progress)
        },
        (error) => {
          console.error("Error al subir video:", error)
          setError(`Error al subir video: ${error.message}`)
          setSubmitting(false)
        },
        async () => {
          // Subida completada exitosamente
          try {
            // Obtener la URL de descarga del video
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref)

            // Guardar la información del video en la base de datos
            await push(databaseRef(database, "videos"), {
              titulo,
              descripcion,
              cursoAsignado,
              cursoNombre: cursoSeleccionado?.nombre || "",
              cursoNivel: cursoSeleccionado?.nivel || "",
              videoUrl: downloadURL,
              fechaSubida: new Date().toISOString(),
            })

            setSuccess("Video subido exitosamente")
            setTitulo("")
            setDescripcion("")
            setVideoFile(null)
            setUploadProgress(0)
            if (fileInputRef.current) {
              fileInputRef.current.value = ""
            }
          } catch (error: any) {
            console.error("Error al guardar información del video:", error)
            setError(`Error al guardar información del video: ${error.message}`)
          } finally {
            setSubmitting(false)
          }
        },
      )
    } catch (error: any) {
      console.error("Error:", error)
      setError(error.message)
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Subir Video</h1>
        <Link href="/admin/videos">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver a Videos
          </button>
        </Link>
      </header>

      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold mb-6">Información del Video</h2>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {success && (
            <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
              <p className="text-green-700">{success}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="titulo" className="block text-sm font-medium text-gray-700 mb-1">
                Título del video
              </label>
              <input
                id="titulo"
                type="text"
                placeholder="Ej: Lección 1 - Introducción"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="descripcion" className="block text-sm font-medium text-gray-700 mb-1">
                Descripción del video
              </label>
              <textarea
                id="descripcion"
                placeholder="Describe el contenido del video"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
              />
            </div>

            <div>
              <label htmlFor="cursoAsignado" className="block text-sm font-medium text-gray-700 mb-1">
                Curso asignado
              </label>
              {cursos.length > 0 ? (
                <select
                  id="cursoAsignado"
                  value={cursoAsignado}
                  onChange={(e) => setCursoAsignado(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  {cursos.map((curso) => (
                    <option key={curso.id} value={curso.id}>
                      {curso.nombre} - Nivel {curso.nivel}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="text-yellow-600 bg-yellow-50 p-3 rounded-lg">
                  <p>No hay cursos disponibles. Por favor, crea un curso primero.</p>
                  <Link href="/admin/cursos/crear">
                    <button className="text-blue-600 underline mt-2">Crear un curso</button>
                  </Link>
                </div>
              )}
            </div>

            <div>
              <label htmlFor="video" className="block text-sm font-medium text-gray-700 mb-1">
                Archivo de video
              </label>
              <input
                id="video"
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="video/*"
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <p className="text-xs text-gray-500 mt-1">Formatos aceptados: MP4, WebM, MOV (máx. 100MB)</p>
              <p className="text-xs text-yellow-600 mt-1">
                Nota: Para videos más grandes, considera comprimirlos o dividirlos en partes más pequeñas.
              </p>
            </div>

            {uploadProgress > 0 && uploadProgress < 100 && (
              <div className="mt-4">
                <p className="text-sm font-medium text-gray-700 mb-1">Subiendo video: {uploadProgress}%</p>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
                </div>
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting || !videoFile || cursos.length === 0}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              >
                {submitting ? "Subiendo..." : "Subir Video"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
