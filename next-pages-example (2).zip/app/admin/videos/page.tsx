"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, remove, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Video {
  id: string
  titulo: string
  descripcion: string
  cursoAsignado: string
  videoUrl: string
  fechaSubida: string
  cursoNombre?: string
}

interface Curso {
  id: string
  nombre: string
  nivel: string
}

export default function VideosAdmin() {
  const [videos, setVideos] = useState<Video[]>([])
  const [cursos, setCursos] = useState<Record<string, Curso>>({})
  const [loading, setLoading] = useState(true)
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null)
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin" && userData.role !== "profesor") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin" && role !== "profesor") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos
  useEffect(() => {
    if (loading || !database) return

    const cursosRef = ref(database, "cursos")
    const unsubscribeCursos = onValue(cursosRef, (snapshot) => {
      if (snapshot.exists()) {
        const cursosData = snapshot.val()
        const cursosMap: Record<string, Curso> = {}

        Object.entries(cursosData).forEach(([id, data]: [string, any]) => {
          cursosMap[id] = {
            id,
            nombre: data.nombre || "Sin nombre",
            nivel: data.nivel || "Sin nivel",
          }
        })

        setCursos(cursosMap)
      }
    })

    return () => unsubscribeCursos()
  }, [loading, database])

  // Cargar videos
  useEffect(() => {
    if (loading || !database) return

    const videosRef = ref(database, "videos")
    const unsubscribeVideos = onValue(videosRef, (snapshot) => {
      if (snapshot.exists()) {
        const videosData = snapshot.val()
        const videosArray = Object.entries(videosData).map(([id, data]: [string, any]) => ({
          id,
          titulo: data.titulo || "Sin título",
          descripcion: data.descripcion || "",
          cursoAsignado: data.cursoAsignado || "",
          videoUrl: data.videoUrl || "",
          fechaSubida: data.fechaSubida || new Date().toISOString(),
        }))

        // Añadir el nombre del curso a cada video
        const videosConCurso = videosArray.map((video) => ({
          ...video,
          cursoNombre: cursos[video.cursoAsignado]?.nombre || "Curso no encontrado",
        }))

        setVideos(videosConCurso)
      } else {
        setVideos([])
      }
    })

    return () => unsubscribeVideos()
  }, [loading, database, cursos])

  // Eliminar video
  const handleDelete = async (id: string) => {
    if (!database) return

    if (confirm("¿Estás seguro de que deseas eliminar este video?")) {
      try {
        await remove(ref(database, `videos/${id}`))
        setVideos(videos.filter((video) => video.id !== id))
        if (selectedVideo?.id === id) {
          setSelectedVideo(null)
        }
      } catch (error) {
        console.error("Error al eliminar video:", error)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Administración de Videos</h1>
        <Link href="/admin">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver al Panel
          </button>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Videos</h2>
          <Link href="/admin/videos/subir">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Subir Nuevo Video</button>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Lista de videos */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h3 className="text-lg font-semibold">Videos Disponibles</h3>
            </div>
            <div className="overflow-y-auto max-h-[600px]">
              {videos.length > 0 ? (
                <ul className="divide-y divide-gray-200">
                  {videos.map((video) => (
                    <li
                      key={video.id}
                      className={`p-4 hover:bg-gray-50 cursor-pointer ${
                        selectedVideo?.id === video.id ? "bg-blue-50" : ""
                      }`}
                      onClick={() => setSelectedVideo(video)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">{video.titulo}</h4>
                          <p className="text-sm text-gray-500 mt-1">Curso: {video.cursoNombre}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            Subido: {new Date(video.fechaSubida).toLocaleDateString()}
                          </p>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDelete(video.id)
                          }}
                          className="text-red-600 hover:text-red-900 text-sm"
                        >
                          Eliminar
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="p-4 text-center text-gray-500">No hay videos disponibles</p>
              )}
            </div>
          </div>

          {/* Reproductor de video */}
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h3 className="text-lg font-semibold">Reproductor</h3>
            </div>
            {selectedVideo ? (
              <div className="p-4">
                <div className="aspect-w-16 aspect-h-9 mb-4">
                  <video
                    src={selectedVideo.videoUrl}
                    controls
                    className="w-full h-full object-cover rounded-lg"
                  ></video>
                </div>
                <h3 className="text-xl font-semibold">{selectedVideo.titulo}</h3>
                <p className="text-gray-500 mt-2">{selectedVideo.descripcion}</p>
                <div className="mt-4 text-sm text-gray-500">
                  <p>Curso: {selectedVideo.cursoNombre}</p>
                  <p>Fecha de subida: {new Date(selectedVideo.fechaSubida).toLocaleDateString()}</p>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-gray-500 h-full flex items-center justify-center">
                <p>Selecciona un video para reproducir</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
