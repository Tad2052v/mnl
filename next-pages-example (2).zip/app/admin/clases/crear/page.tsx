"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, push, get } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Curso {
  id: string
  nombre: string
  nivel: string
}

export default function CrearClase() {
  const [nombre, setNombre] = useState("")
  const [descripcion, setDescripcion] = useState("")
  const [hora, setHora] = useState("")
  const [linkReunion, setLinkReunion] = useState("")
  const [nivel, setNivel] = useState("A1")
  const [cursoAsignado, setCursoAsignado] = useState("")
  const [cursos, setCursos] = useState<Curso[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar cursos disponibles
  useEffect(() => {
    if (loading || !database) return

    const fetchCursos = async () => {
      try {
        const cursosRef = ref(database, "cursos")
        const snapshot = await get(cursosRef)

        if (snapshot.exists()) {
          const cursosData = snapshot.val()
          const cursosArray = Object.entries(cursosData).map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            nivel: data.nivel || "Sin nivel",
          }))
          setCursos(cursosArray)

          // Seleccionar el primer curso por defecto si hay cursos disponibles
          if (cursosArray.length > 0) {
            setCursoAsignado(cursosArray[0].id)
            setNivel(cursosArray[0].nivel)
          }
        }
      } catch (error) {
        console.error("Error al cargar cursos:", error)
      }
    }

    fetchCursos()
  }, [loading, database])

  // Actualizar nivel cuando cambia el curso seleccionado
  useEffect(() => {
    if (cursoAsignado) {
      const cursoSeleccionado = cursos.find((curso) => curso.id === cursoAsignado)
      if (cursoSeleccionado) {
        setNivel(cursoSeleccionado.nivel)
      }
    }
  }, [cursoAsignado, cursos])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSubmitting(true)

    try {
      if (!database) {
        throw new Error("Firebase no está inicializado")
      }

      // Encontrar el nombre del curso seleccionado
      const cursoSeleccionado = cursos.find((curso) => curso.id === cursoAsignado)

      await push(ref(database, "clases"), {
        nombre,
        descripcion,
        hora,
        linkReunion,
        nivel,
        cursoAsignado,
        cursoNombre: cursoSeleccionado?.nombre || "",
        fecha: new Date().toISOString(),
      })

      router.push("/admin/clases")
    } catch (error: any) {
      console.error("Error al crear clase:", error)
      setError(`Error al crear la clase: ${error.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Crear Nueva Clase</h1>
        <Link href="/admin/clases">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver a Clases
          </button>
        </Link>
      </header>

      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold mb-6">Información de la Clase</h2>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="cursoAsignado" className="block text-sm font-medium text-gray-700 mb-1">
                Curso asignado
              </label>
              {cursos.length > 0 ? (
                <select
                  id="cursoAsignado"
                  value={cursoAsignado}
                  onChange={(e) => setCursoAsignado(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  {cursos.map((curso) => (
                    <option key={curso.id} value={curso.id}>
                      {curso.nombre} - Nivel {curso.nivel}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="text-yellow-600 bg-yellow-50 p-3 rounded-lg">
                  <p>No hay cursos disponibles. Por favor, crea un curso primero.</p>
                  <Link href="/admin/cursos/crear">
                    <button className="text-blue-600 underline mt-2">Crear un curso</button>
                  </Link>
                </div>
              )}
            </div>

            <div>
              <label htmlFor="nombre" className="block text-sm font-medium text-gray-700 mb-1">
                Nombre de la clase
              </label>
              <input
                id="nombre"
                type="text"
                placeholder="Ej: Introducción a la gramática"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="nivel" className="block text-sm font-medium text-gray-700 mb-1">
                Nivel
              </label>
              <input
                id="nivel"
                type="text"
                value={nivel}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 bg-gray-100"
                readOnly
              />
              <p className="text-xs text-gray-500 mt-1">
                El nivel se determina automáticamente según el curso seleccionado
              </p>
            </div>

            <div>
              <label htmlFor="descripcion" className="block text-sm font-medium text-gray-700 mb-1">
                Descripción de la clase
              </label>
              <textarea
                id="descripcion"
                placeholder="Describe el contenido y objetivos de la clase"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={4}
              />
            </div>

            <div>
              <label htmlFor="hora" className="block text-sm font-medium text-gray-700 mb-1">
                Hora de la clase
              </label>
              <input
                id="hora"
                type="time"
                value={hora}
                onChange={(e) => setHora(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="linkReunion" className="block text-sm font-medium text-gray-700 mb-1">
                Enlace de la reunión
              </label>
              <input
                id="linkReunion"
                type="url"
                placeholder="https://meet.google.com/..."
                value={linkReunion}
                onChange={(e) => setLinkReunion(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
              <p className="text-xs text-gray-500 mt-1">Ingresa un enlace válido para la videoconferencia</p>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting || cursos.length === 0}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              >
                {submitting ? "Creando..." : "Crear Clase"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
