"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, remove } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Clase {
  id: string
  nombre: string
  descripcion: string
  hora: string
  linkReunion: string
  nivel: string
  fecha?: string
}

export default function ClasesAdmin() {
  const [clases, setClases] = useState<Clase[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar clases existentes
  useEffect(() => {
    const fetchClases = async () => {
      if (!database) return

      try {
        const clasesRef = ref(database, "clases")
        const snapshot = await get(clasesRef)

        if (snapshot.exists()) {
          const clasesData = snapshot.val()
          const clasesArray = Object.entries(clasesData).map(([id, data]: [string, any]) => ({
            id,
            ...data,
          }))
          setClases(clasesArray)
        }
      } catch (error) {
        console.error("Error al cargar clases:", error)
      }
    }

    if (!loading) {
      fetchClases()
    }
  }, [loading, database])

  // Eliminar clase
  const handleDelete = async (id: string) => {
    if (!database) return

    if (confirm("¿Estás seguro de que deseas eliminar esta clase?")) {
      try {
        await remove(ref(database, `clases/${id}`))
        setClases(clases.filter((clase) => clase.id !== id))
      } catch (error) {
        console.error("Error al eliminar clase:", error)
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Administración de Clases</h1>
        <Link href="/admin">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver al Panel
          </button>
        </Link>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Clases</h2>
          <Link href="/admin/clases/crear">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">Crear Nueva Clase</button>
          </Link>
        </div>

        {/* Lista de clases */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {clases.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Nombre
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Nivel
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Hora
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Enlace
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {clases.map((clase) => (
                    <tr key={clase.id}>
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{clase.nombre}</div>
                        <div className="text-sm text-gray-500 truncate max-w-xs">{clase.descripcion}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          {clase.nivel || "No especificado"}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-gray-900">{clase.hora}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <a
                          href={clase.linkReunion}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-900"
                        >
                          Abrir enlace
                        </a>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button onClick={() => handleDelete(clase.id)} className="text-red-600 hover:text-red-900 mr-4">
                          Eliminar
                        </button>
                        <Link href={`/admin/clases/editar/${clase.id}`} className="text-blue-600 hover:text-blue-900">
                          Editar
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-6 text-center text-gray-500">
              No hay clases disponibles. Crea una nueva clase para comenzar.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
