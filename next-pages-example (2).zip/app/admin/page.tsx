"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { onAuthStateChanged } from "firebase/auth"
import { ref, get } from "firebase/database"
import { auth, database } from "@/lib/firebase"

export default function AdminPanel() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Verificar autenticación y rol
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const snapshot = await get(ref(database, `users/${user.uid}`))
            const role = snapshot.val()?.role

            if (role !== "admin") {
              if (role === "profesor") {
                router.push("/profesor")
              } else if (role === "estudiante") {
                router.push("/estudiante")
              } else {
                router.push("/login")
              }
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Panel de Administrador</h1>
        <button
          onClick={handleLogout}
          className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
        >
          Cerrar sesión
        </button>
      </header>

      <div className="p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Gestión de Usuarios y Contenido</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Link href="/admin/users">
              <div className="bg-blue-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-blue-100">
                <h3 className="text-lg font-medium text-blue-700 mb-2">Crear nuevo usuario</h3>
                <p className="text-gray-600 text-sm">Añade estudiantes, profesores o administradores</p>
              </div>
            </Link>

            <Link href="/admin/usuarios/gestionar">
              <div className="bg-indigo-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-indigo-100">
                <h3 className="text-lg font-medium text-indigo-700 mb-2">Gestionar usuarios</h3>
                <p className="text-gray-600 text-sm">Cambia cursos y gestiona usuarios existentes</p>
              </div>
            </Link>

            <Link href="/admin/cursos">
              <div className="bg-yellow-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-yellow-100">
                <h3 className="text-lg font-medium text-yellow-700 mb-2">Gestionar cursos</h3>
                <p className="text-gray-600 text-sm">Administra los cursos y asigna estudiantes y profesores</p>
              </div>
            </Link>

            <Link href="/admin/videos">
              <div className="bg-green-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-green-100">
                <h3 className="text-lg font-medium text-green-700 mb-2">Subir nuevo video</h3>
                <p className="text-gray-600 text-sm">Sube contenido multimedia para las clases</p>
              </div>
            </Link>

            <Link href="/admin/tareas">
              <div className="bg-purple-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-purple-100">
                <h3 className="text-lg font-medium text-purple-700 mb-2">Crear nueva tarea</h3>
                <p className="text-gray-600 text-sm">Crea actividades para los estudiantes</p>
              </div>
            </Link>

            <Link href="/admin/clases">
              <div className="bg-orange-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-orange-100">
                <h3 className="text-lg font-medium text-orange-700 mb-2">Crear nueva clase</h3>
                <p className="text-gray-600 text-sm">Configura nuevas clases y módulos</p>
              </div>
            </Link>

            <Link href="/admin/cursos/crear">
              <div className="bg-green-50 p-6 rounded-xl shadow hover:shadow-md transition-shadow border border-green-100">
                <h3 className="text-lg font-medium text-green-700 mb-2">Crear nuevo curso</h3>
                <p className="text-gray-600 text-sm">Añade cursos para los estudiantes</p>
              </div>
            </Link>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-semibold mb-4">Acciones Rápidas</h2>
          <ul className="space-y-2 bg-gray-50 p-6 rounded-xl border border-gray-200">
            <li>
              <Link href="/admin/users" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">👤</span> Crear usuarios
              </Link>
            </li>
            <li>
              <Link href="/admin/usuarios/gestionar" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">👥</span> Gestionar usuarios existentes
              </Link>
            </li>
            <li>
              <Link href="/admin/videos" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">🎬</span> Gestionar videos
              </Link>
            </li>
            <li>
              <Link href="/admin/tareas" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">📝</span> Gestionar tareas
              </Link>
            </li>
            <li>
              <Link href="/admin/clases" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">📚</span> Gestionar clases
              </Link>
            </li>
            <li>
              <Link href="/admin/cursos" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">🏫</span> Gestionar cursos
              </Link>
            </li>
            <li>
              <Link href="/admin/cursos/crear" className="text-blue-600 hover:text-blue-800 flex items-center">
                <span className="mr-2">➕</span> Crear nuevo curso
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}
