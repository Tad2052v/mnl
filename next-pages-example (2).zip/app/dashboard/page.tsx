"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ref, get } from "firebase/database"
import { onAuthStateChanged } from "firebase/auth"
import { auth, database } from "@/lib/firebase"

export default function RedirectToPanel() {
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const checkAuthAndRedirect = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          const role = userData.role || "estudiante"
          router.push(`/${role}`)
        } catch (e) {
          console.error("Error al parsear usuario local:", e)
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (user) {
          try {
            // Obtener el rol del usuario desde Firebase
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)

            if (snapshot.exists()) {
              const userData = snapshot.val()
              const role = userData.role || "estudiante"

              // Redirigir dependiendo del rol
              router.push(`/${role}`)
            } else {
              // Si no existe el rol, redirige a la página de login
              router.push("/login")
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          }
        } else {
          router.push("/login") // Redirige al login si el usuario no está autenticado
        }
        setLoading(false)
      })

      return () => unsubscribe()
    }

    checkAuthAndRedirect()
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-xl text-gray-700">Redireccionando...</p>
        </div>
      </div>
    )
  }

  return null
}
