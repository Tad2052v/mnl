"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ref, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Tarea {
  id: string
  titulo: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre?: string
}

interface Clase {
  id: string
  nombre: string
  hora: string
  nivel: string
}

interface Estudiante {
  id: string
  email: string
  nombre?: string
}

export default function ProfesorDashboard() {
  const [tareas, setTareas] = useState<Tarea[]>([])
  const [clases, setClases] = useState<Clase[]>([])
  const [estudiantes, setEstudiantes] = useState<Estudiante[]>([])
  const [loading, setLoading] = useState(true)
  const [userName, setUserName] = useState("")
  const router = useRouter()

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "profesor") {
            router.push(`/${userData.role}`)
          }
          setUserName(userData.email?.split("@")[0] || "Profesor")
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const userData = snapshot.val()
            const role = userData?.role

            setUserName(user.email?.split("@")[0] || "Profesor")

            if (role !== "profesor") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar datos del dashboard
  useEffect(() => {
    if (loading || !database) return

    // Cargar tareas
    const tareasRef = ref(database, "tareas")
    const unsubscribeTareas = onValue(tareasRef, (snapshot) => {
      if (snapshot.exists()) {
        const tareasData = snapshot.val()
        const tareasArray = Object.entries(tareasData)
          .map(([id, data]: [string, any]) => ({
            id,
            titulo: data.titulo || "Sin título",
            fechaEntrega: data.fechaEntrega || "Sin fecha",
            claseAsignada: data.claseAsignada || "",
            claseNombre: data.claseNombre || "",
          }))
          .slice(0, 5) // Mostrar solo las 5 más recientes
        setTareas(tareasArray)
      }
    })

    // Cargar clases
    const clasesRef = ref(database, "clases")
    const unsubscribeClases = onValue(clasesRef, (snapshot) => {
      if (snapshot.exists()) {
        const clasesData = snapshot.val()
        const clasesArray = Object.entries(clasesData)
          .map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            hora: data.hora || "Sin hora",
            nivel: data.nivel || "Sin nivel",
          }))
          .slice(0, 5) // Mostrar solo las 5 más recientes
        setClases(clasesArray)
      }
    })

    // Cargar estudiantes
    const usuariosRef = ref(database, "users")
    const unsubscribeUsuarios = onValue(usuariosRef, (snapshot) => {
      if (snapshot.exists()) {
        const usuariosData = snapshot.val()
        const estudiantesArray = Object.entries(usuariosData)
          .filter(([_, data]: [string, any]) => data.role === "estudiante")
          .map(([id, data]: [string, any]) => ({
            id,
            email: data.email || "Sin correo",
            nombre: data.nombre || data.email?.split("@")[0] || "Sin nombre",
          }))
          .slice(0, 5) // Mostrar solo los 5 más recientes
        setEstudiantes(estudiantesArray)
      }
    })

    return () => {
      unsubscribeTareas()
      unsubscribeClases()
      unsubscribeUsuarios()
    }
  }, [loading, database])

  const handleLogout = () => {
    localStorage.removeItem("user")
    if (auth) {
      auth.signOut()
    }
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dashboard Profesor</h1>
        <div className="flex items-center space-x-4">
          <span>Hola, {userName}</span>
          <Link href="/profesor">
            <button className="bg-blue-600 text-white px-4 py-1 rounded-lg text-sm font-medium hover:bg-blue-500">
              Panel Principal
            </button>
          </Link>
          <button
            onClick={handleLogout}
            className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100"
          >
            Cerrar sesión
          </button>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-lg font-semibold mb-2 text-blue-700">Clases</h2>
            <div className="text-3xl font-bold">{clases.length}</div>
            <div className="mt-2 text-sm text-gray-500">Clases asignadas</div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-lg font-semibold mb-2 text-green-700">Tareas</h2>
            <div className="text-3xl font-bold">{tareas.length}</div>
            <div className="mt-2 text-sm text-gray-500">Tareas creadas</div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-lg font-semibold mb-2 text-purple-700">Estudiantes</h2>
            <div className="text-3xl font-bold">{estudiantes.length}</div>
            <div className="mt-2 text-sm text-gray-500">Estudiantes asignados</div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Próximas Clases</h2>
              <Link href="/profesor/clases">
                <button className="text-blue-600 text-sm hover:underline">Ver todas</button>
              </Link>
            </div>
            {clases.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Nombre
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Hora
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Nivel
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {clases.map((clase) => (
                      <tr key={clase.id}>
                        <td className="px-4 py-2 whitespace-nowrap">{clase.nombre}</td>
                        <td className="px-4 py-2 whitespace-nowrap">{clase.hora}</td>
                        <td className="px-4 py-2 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                            {clase.nivel}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No hay clases programadas</p>
            )}
          </div>

          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Tareas Asignadas</h2>
              <Link href="/profesor/tareas">
                <button className="text-blue-600 text-sm hover:underline">Ver todas</button>
              </Link>
            </div>
            {tareas.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Título
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fecha de Entrega
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Clase
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {tareas.map((tarea) => (
                      <tr key={tarea.id}>
                        <td className="px-4 py-2 whitespace-nowrap">{tarea.titulo}</td>
                        <td className="px-4 py-2 whitespace-nowrap">{tarea.fechaEntrega}</td>
                        <td className="px-4 py-2 whitespace-nowrap">{tarea.claseNombre || "Sin especificar"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No hay tareas asignadas</p>
            )}
          </div>
        </div>

        <div className="mt-6">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Estudiantes</h2>
              <Link href="/profesor/estudiantes">
                <button className="text-blue-600 text-sm hover:underline">Ver todos</button>
              </Link>
            </div>
            {estudiantes.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Nombre
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {estudiantes.map((estudiante) => (
                      <tr key={estudiante.id}>
                        <td className="px-4 py-2 whitespace-nowrap">{estudiante.email}</td>
                        <td className="px-4 py-2 whitespace-nowrap">{estudiante.nombre}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500 text-center py-4">No hay estudiantes asignados</p>
            )}
          </div>
        </div>

        <div className="mt-8 bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold mb-4">Acciones Rápidas</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Link href="/profesor/tareas/crear">
              <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700">
                Crear Tarea
              </button>
            </Link>
            <Link href="/profesor/clases">
              <button className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700">
                Ver Clases
              </button>
            </Link>
            <Link href="/profesor/estudiantes">
              <button className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700">
                Ver Estudiantes
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
