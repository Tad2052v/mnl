"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { ref, update, get, onValue } from "firebase/database"
import { database, auth } from "@/lib/firebase"
import Link from "next/link"
import { onAuthStateChanged } from "firebase/auth"

interface Clase {
  id: string
  nombre: string
  nivel: string
}

interface Tarea {
  titulo: string
  descripcion: string
  fechaEntrega: string
  claseAsignada: string
  claseNombre: string
  entregado: boolean
}

export default function EditarTarea() {
  const [titulo, setTitulo] = useState("")
  const [descripcion, setDescripcion] = useState("")
  const [fechaEntrega, setFechaEntrega] = useState("")
  const [claseAsignada, setClaseAsignada] = useState("")
  const [clases, setClases] = useState<Clase[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [tareaExiste, setTareaExiste] = useState(false)
  const router = useRouter()
  const params = useParams()
  const tareaId = params.id as string

  // Verificar autenticación
  useEffect(() => {
    const checkAuth = async () => {
      // Si no hay Firebase, intentar con localStorage
      if (!auth || !database) {
        const userStr = localStorage.getItem("user")
        if (!userStr) {
          router.push("/login")
          return
        }

        try {
          const userData = JSON.parse(userStr)
          if (userData.role !== "profesor" && userData.role !== "admin") {
            router.push(`/${userData.role}`)
          }
        } catch (e) {
          router.push("/login")
        } finally {
          setLoading(false)
        }
        return
      }

      // Si hay Firebase, usar onAuthStateChanged
      const unsubscribe = onAuthStateChanged(auth, async (user) => {
        if (!user) {
          router.push("/login")
        } else {
          try {
            const userRef = ref(database, `users/${user.uid}`)
            const snapshot = await get(userRef)
            const role = snapshot.val()?.role

            if (role !== "profesor" && role !== "admin") {
              router.push(`/${role || "login"}`)
            }
          } catch (error) {
            console.error("Error al verificar rol:", error)
            router.push("/login")
          } finally {
            setLoading(false)
          }
        }
      })

      return () => unsubscribe()
    }

    checkAuth()
  }, [router])

  // Cargar clases disponibles
  useEffect(() => {
    if (loading || !database) return

    const fetchClases = async () => {
      try {
        const clasesRef = ref(database, "clases")
        const snapshot = await get(clasesRef)

        if (snapshot.exists()) {
          const clasesData = snapshot.val()
          const clasesArray = Object.entries(clasesData).map(([id, data]: [string, any]) => ({
            id,
            nombre: data.nombre || "Sin nombre",
            nivel: data.nivel || "Sin nivel",
          }))
          setClases(clasesArray)
        }
      } catch (error) {
        console.error("Error al cargar clases:", error)
      }
    }

    fetchClases()
  }, [loading, database])

  // Cargar datos de la tarea
  useEffect(() => {
    if (loading || !database || !tareaId) return

    const tareaRef = ref(database, `tareas/${tareaId}`)
    const unsubscribe = onValue(tareaRef, (snapshot) => {
      if (snapshot.exists()) {
        const tareaData = snapshot.val() as Tarea
        setTitulo(tareaData.titulo || "")
        setDescripcion(tareaData.descripcion || "")
        setFechaEntrega(tareaData.fechaEntrega || "")
        setClaseAsignada(tareaData.claseAsignada || "")
        setTareaExiste(true)
      } else {
        setError("La tarea no existe")
        setTareaExiste(false)
      }
    })

    return () => unsubscribe()
  }, [loading, database, tareaId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")
    setSubmitting(true)

    try {
      if (!database) {
        throw new Error("Firebase no está inicializado")
      }

      if (!tareaExiste) {
        throw new Error("La tarea no existe")
      }

      // Validar datos
      if (!titulo.trim()) {
        throw new Error("El título de la tarea es obligatorio")
      }

      if (!descripcion.trim()) {
        throw new Error("La descripción de la tarea es obligatoria")
      }

      if (!fechaEntrega) {
        throw new Error("La fecha de entrega es obligatoria")
      }

      if (!claseAsignada) {
        throw new Error("Debe seleccionar una clase para asignar la tarea")
      }

      // Encontrar el nombre de la clase seleccionada
      const claseSeleccionada = clases.find((clase) => clase.id === claseAsignada)

      // Actualizar la tarea en la base de datos
      await update(ref(database, `tareas/${tareaId}`), {
        titulo,
        descripcion,
        fechaEntrega,
        claseAsignada,
        claseNombre: claseSeleccionada?.nombre || "",
        fechaActualizacion: new Date().toISOString(),
      })

      setSuccess("Tarea actualizada exitosamente")
    } catch (error: any) {
      console.error("Error al actualizar tarea:", error)
      setError(`Error al actualizar la tarea: ${error.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl">Cargando...</p>
      </div>
    )
  }

  if (!tareaExiste && !loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
          <h1 className="text-2xl font-bold">Editar Tarea</h1>
          <Link href="/profesor/tareas">
            <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
              Volver a Tareas
            </button>
          </Link>
        </header>

        <div className="max-w-2xl mx-auto p-6">
          <div className="bg-white p-8 rounded-xl shadow-md text-center">
            <h2 className="text-2xl font-bold mb-4 text-red-600">Error</h2>
            <p className="text-gray-700 mb-6">La tarea que intentas editar no existe o ha sido eliminada.</p>
            <Link href="/profesor/tareas">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700">
                Volver a la lista de tareas
              </button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-blue-700 text-white py-4 px-8 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Editar Tarea</h1>
        <Link href="/profesor/tareas">
          <button className="bg-white text-blue-700 px-4 py-1 rounded-lg text-sm font-medium hover:bg-gray-100">
            Volver a Tareas
          </button>
        </Link>
      </header>

      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-white p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold mb-6">Información de la Tarea</h2>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {success && (
            <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-6">
              <p className="text-green-700">{success}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="titulo" className="block text-sm font-medium text-gray-700 mb-1">
                Título de la tarea
              </label>
              <input
                id="titulo"
                type="text"
                placeholder="Ej: Ejercicios de gramática"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="descripcion" className="block text-sm font-medium text-gray-700 mb-1">
                Descripción de la tarea
              </label>
              <textarea
                id="descripcion"
                placeholder="Describe los detalles y requisitos de la tarea"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={5}
                required
              />
            </div>

            <div>
              <label htmlFor="fechaEntrega" className="block text-sm font-medium text-gray-700 mb-1">
                Fecha de entrega
              </label>
              <input
                id="fechaEntrega"
                type="date"
                value={fechaEntrega}
                onChange={(e) => setFechaEntrega(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="claseAsignada" className="block text-sm font-medium text-gray-700 mb-1">
                Clase asignada
              </label>
              {clases.length > 0 ? (
                <select
                  id="claseAsignada"
                  value={claseAsignada}
                  onChange={(e) => setClaseAsignada(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  {clases.map((clase) => (
                    <option key={clase.id} value={clase.id}>
                      {clase.nombre} - Nivel {clase.nivel}
                    </option>
                  ))}
                </select>
              ) : (
                <div className="text-yellow-600 bg-yellow-50 p-3 rounded-lg">
                  <p>No hay clases disponibles. Por favor, crea una clase primero.</p>
                  <Link href="/profesor/clases/crear">
                    <button className="text-blue-600 underline mt-2">Crear una clase</button>
                  </Link>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={submitting || clases.length === 0}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:bg-blue-400"
              >
                {submitting ? "Actualizando..." : "Actualizar Tarea"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  )
}
