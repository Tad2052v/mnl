import Link from "next/link"

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-800">
      {/* Encabezado principal */}
      <header className="bg-blue-700 text-white py-10 shadow-md">
        <div className="max-w-6xl mx-auto px-6 text-center">
          <h1 className="text-5xl font-extrabold mb-4">Idioma Sin Límites</h1>
          <p className="text-lg max-w-2xl mx-auto">
            Una plataforma educativa inclusiva que conecta a personas de todo el mundo para aprender nuevos idiomas de
            forma dinámica, sencilla y profesional.
          </p>
          <div className="mt-6">
            <Link href="/login">
              <button className="bg-white text-blue-700 font-semibold px-6 py-2 rounded-xl shadow hover:bg-gray-100">
                Ingresar al sistema
              </button>
            </Link>
          </div>
        </div>
      </header>

      {/* Estadísticas o beneficios */}
      <section className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-3 gap-8 text-center">
        <div>
          <h2 className="text-4xl font-bold text-blue-600">+100</h2>
          <p className="mt-2 text-gray-600">Cursos disponibles</p>
        </div>
        <div>
          <h2 className="text-4xl font-bold text-blue-600">+2000</h2>
          <p className="mt-2 text-gray-600">Estudiantes inscritos</p>
        </div>
        <div>
          <h2 className="text-4xl font-bold text-blue-600">10+</h2>
          <p className="mt-2 text-gray-600">Idiomas disponibles</p>
        </div>
      </section>

      {/* Sobre nosotros */}
      <section className="bg-gray-100 py-20">
        <div className="max-w-5xl mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold mb-6">¿Quiénes somos?</h2>
          <p className="text-lg leading-relaxed">
            Somos un equipo de docentes y especialistas en lingüística apasionados por la enseñanza de idiomas. Nuestro
            objetivo es crear una experiencia de aprendizaje única, accesible y de alta calidad, tanto para hablantes
            nativos de español como para personas extranjeras.
          </p>
        </div>
      </section>

      {/* Llamado a la acción */}
      <section className="py-20 bg-blue-700 text-white text-center">
        <div className="max-w-3xl mx-auto px-6">
          <h2 className="text-4xl font-bold mb-4">Comienza tu viaje lingüístico hoy</h2>
          <p className="mb-6">Únete a nuestra comunidad de estudiantes y explora el mundo a través de los idiomas.</p>
          <button className="bg-white text-blue-700 font-semibold px-8 py-3 rounded-xl hover:bg-gray-100">
            Muy pronto disponible
          </button>
        </div>
      </section>

      {/* Pie de página */}
      <footer className="bg-gray-200 text-gray-600 text-center py-6 text-sm">
        © 2025 Idioma Sin Límites | Todos los derechos reservados
      </footer>
    </main>
  )
}
