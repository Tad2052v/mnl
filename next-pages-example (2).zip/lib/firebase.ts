// Configuración de Firebase
import { initializeApp, getApps } from "firebase/app"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { getAnalytics } from "firebase/analytics"
import { getDatabase } from "firebase/database"

// Configuración de Firebase proporcionada
const firebaseConfig = {
  apiKey: "AIzaSyCcRVdJ9ZQZ2tYLPAvBmEsBCI-SLNzeIfU",
  authDomain: "idioma-sin-limites.firebaseapp.com",
  projectId: "idioma-sin-limites",
  storageBucket: "idioma-sin-limites.firebasestorage.app",
  messagingSenderId: "917473254539",
  appId: "1:917473254539:web:b1af74aab85f9912fb488e",
  measurementId: "G-GNGD86X8J3",
  databaseURL: "https://idioma-sin-limites-default-rtdb.firebaseio.com", // URL para Realtime Database
}

// Variables para exportar
let app
let auth
let db
let storage
let analytics
let database

// Inicializar Firebase solo en el cliente
if (typeof window !== "undefined") {
  try {
    if (!getApps().length) {
      app = initializeApp(firebaseConfig)
    } else {
      app = getApps()[0]
    }

    auth = getAuth(app)
    db = getFirestore(app)
    storage = getStorage(app)
    database = getDatabase(app)

    // Inicializar analytics solo en el cliente
    analytics = getAnalytics(app)

    console.log("Firebase inicializado correctamente")
  } catch (error) {
    console.error("Error al inicializar Firebase:", error)
  }
}

export { app, auth, db, storage, analytics, database }
export default app
